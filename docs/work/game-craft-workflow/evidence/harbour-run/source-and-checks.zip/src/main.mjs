import * as THREE from '../vendor/three.module.js';
import { buildWorld } from './world.mjs';
import { createState, reset, step, pause, resume, GATES, FINISH, STEP, clamp } from './simulation.mjs';
import { HarbourAudio } from './audio.mjs';

const $ = id => document.getElementById(id);
const canvas = $('world');
const ui = Object.fromEntries(['hud', 'intro', 'intro-caption', 'time', 'speed', 'speed-bar', 'drive-state', 'best', 'callout', 'gate-label', 'gate-number', 'gate-dots', 'route-hint', 'pause-modal', 'result-modal'].map(id => [id, $(id)]));
const keys = new Set();
const input = { throttle: false, brake: false, handbrake: false, steer: 0 };
const state = createState();
const audio = new HarbourAudio();
const storageKey = 'harbour-run.best.v1';
let best = null, storageAvailable = true;
try { const stored = Number(localStorage.getItem(storageKey)); if (Number.isFinite(stored) && stored > 0) best = stored; } catch { storageAvailable = false; }
const formatTime = t => { const hundredths = Math.floor(t * 100 + 1e-6); return `${String(Math.floor(hundredths / 6000)).padStart(2, '0')}:${String(Math.floor(hundredths / 100) % 60).padStart(2, '0')}.${String(hundredths % 100).padStart(2, '0')}`; };
ui.best.textContent = best ? `BEST ${formatTime(best)}` : 'BEST —';
const dots = GATES.map((_, i) => { const dot = document.createElement('i'); dot.className = 'race-route__dot' + (i === 0 ? ' is-current' : ''); ui['gate-dots'].append(dot); return dot; });
let renderer;
try {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
} catch (err) {
  $('error').hidden = false; $('error-detail').textContent = 'Harbour Run needs WebGL 2. Enable graphics acceleration in your browser, then try again.';
  throw err;
}
renderer.setPixelRatio(1);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(48, 1, .1, 360);
const world = buildWorld(scene);
const lookAt = new THREE.Vector3(), desiredCamera = new THREE.Vector3(), desiredLook = new THREE.Vector3();
const dummy = new THREE.Object3D();
const previous = { x: state.x, z: state.z, yaw: state.yaw };
let cameraYaw = 0, springPitch = 0, pitchVelocity = 0, springRoll = 0, rollVelocity = 0;
let bump = 0, bumpVelocity = 0, shake = 0, shakeX = 0, shakeZ = 0, visualTime = 0, skidIndex = 0, lastSkidDistance = 0;
let calloutUntil = 0, finishPresented = false, lastHud = 0, frameId, disposed = false;
let calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
$('calm').checked = calm;
const frameTimes = new Float32Array(2400); let frameSample = 0, frameCount = 0;
const eventLog = [];

function resize() {
  const w = innerWidth, h = innerHeight, pixelRatio = Math.min(devicePixelRatio, 1.7, Math.sqrt(2_600_000 / (w * h)));
  renderer.setSize(Math.round(w * pixelRatio), Math.round(h * pixelRatio), false);
  camera.aspect = w / h; camera.updateProjectionMatrix();
}
resize();
window.addEventListener('resize', resize);
function syncPrevious() { previous.x = state.x; previous.z = state.z; previous.yaw = state.yaw; }
function clearInput() { keys.clear(); Object.assign(input, { throttle: false, brake: false, handbrake: false, steer: 0 }); }
function readInput() {
  input.throttle = keys.has('KeyW') || keys.has('ArrowUp'); input.brake = keys.has('KeyS') || keys.has('ArrowDown');
  input.handbrake = keys.has('Space');
  input.steer = Number(keys.has('KeyD') || keys.has('ArrowRight')) - Number(keys.has('KeyA') || keys.has('ArrowLeft'));
}
function message(text, seconds = 1.5, warning = false) {
  ui.callout.textContent = text; ui.callout.classList.add('is-visible'); ui.callout.classList.toggle('is-warning', warning); calloutUntil = visualTime + seconds;
}
function updateGates() {
  for (let i = 0; i < GATES.length; i++) {
    const current = i === state.nextGate, done = i < state.nextGate;
    world.gates[i].liveMat.color.setHex(current ? 0x65eabd : done ? 0x57a691 : 0xe9e5ca);
    world.gates[i].liveMat.emissive.setHex(current ? 0x24785b : 0x000000);
    dots[i].classList.toggle('is-current', current); dots[i].classList.toggle('is-done', done);
  }
  ui['gate-dots'].setAttribute('aria-label', `${state.nextGate} of 6 gates cleared`);
  ui['gate-label'].textContent = state.nextGate === 6 ? 'HOME STRETCH' : 'NEXT GATE';
  ui['gate-number'].textContent = state.nextGate === 6 ? '⚑' : String(state.nextGate + 1).padStart(2, '0');
  ui['route-hint'].textContent = state.nextGate === 6 ? 'Through the finish arch' : 'Follow the mint arch';
}
function positionCamera(immediate = false, dt = 1 / 60) {
  if (state.phase === 'menu') {
    camera.position.set(13, 11, 23); lookAt.set(-7, .3, -10); camera.lookAt(lookAt); return;
  }
  // This slalom's travel axis stays north. Partial heading follow keeps the next
  // alternating gate visible and shows the chassis turning beneath the camera.
  const heading = Math.atan2(Math.sin(state.yaw), Math.cos(state.yaw));
  const cameraHeading = clamp(heading * .4, -.34, .34);
  const deltaYaw = cameraHeading - cameraYaw;
  cameraYaw = immediate ? cameraHeading : cameraYaw + deltaYaw * (1 - Math.exp(-3.8 * dt));
  const speed = Math.max(0, state.speed), distance = 14.5 + speed * .10;
  const sin = Math.sin(cameraYaw), cos = Math.cos(cameraYaw);
  desiredCamera.set(world.car.position.x - sin * distance, 10.5 + speed * .025, world.car.position.z + cos * distance);
  desiredLook.set(world.car.position.x + sin * (8 + speed * .13), .4, world.car.position.z - cos * (8 + speed * .13));
  if (immediate) { camera.position.copy(desiredCamera); lookAt.copy(desiredLook); }
  else { camera.position.lerp(desiredCamera, 1 - Math.exp(-7 * dt)); lookAt.lerp(desiredLook, 1 - Math.exp(-9 * dt)); }
  if (!calm && shake > 0) { camera.position.x += shakeX * Math.sin(visualTime * 47) * shake; camera.position.z += shakeZ * Math.sin(visualTime * 43) * shake; }
  camera.lookAt(lookAt);
}
function startRace() {
  audio.start(); clearInput();
  if (ui['pause-modal'].open) ui['pause-modal'].close();
  if (ui['result-modal'].open) ui['result-modal'].close();
  reset(state); syncPrevious();
  ui.intro.hidden = true; ui['intro-caption'].hidden = true; ui.hud.hidden = false;
  finishPresented = false; springPitch = 0; pitchVelocity = 0; springRoll = 0; rollVelocity = 0; bump = 0; bumpVelocity = 0; shake = 0;
  world.car.position.set(state.x, 0, state.z); world.car.rotation.set(0, 0, 0); world.body.rotation.set(0, 0, 0); world.body.position.y = 0;
  for (const wheel of world.wheels) { wheel.wheel.rotation.x = 0; wheel.steering.rotation.y = 0; }
  for (const chip of world.chips) { chip.life = 0; chip.mesh.visible = false; }
  world.skidMesh.count = 0; skidIndex = 0; lastSkidDistance = 0;
  updateGates(); positionCamera(true); message('Hold W or ↑ to roll out', 10000); updateHud(); canvas.focus();
  eventLog.push({ type: 'restart', at: visualTime });
}
function pauseRace() {
  if (state.phase !== 'ready' && state.phase !== 'running') return;
  pause(state); clearInput(); audio.update(state, input); ui['pause-modal'].showModal(); $('resume').focus();
  eventLog.push({ type: 'pause', time: state.time });
}
function resumeRace() {
  ui['pause-modal'].close(); clearInput(); resume(state); syncPrevious(); audio.start(); canvas.focus();
  eventLog.push({ type: 'resume', time: state.time });
}
function finishRace() {
  if (finishPresented) return;
  finishPresented = true; clearInput();
  const oldBest = best, newBest = best === null || state.time < best;
  if (newBest) {
    best = state.time;
    try { localStorage.setItem(storageKey, String(best)); } catch { storageAvailable = false; }
  }
  $('result-time').textContent = formatTime(state.time);
  $('result-record').textContent = newBest ? oldBest ? `New best · ${(oldBest - best).toFixed(2)}s quicker` : 'First time on the board' : `${(state.time - best).toFixed(2)}s from your best`;
  $('result-eyebrow').textContent = newBest ? 'A NEW MARK ON THE QUAY.' : 'SIX GATES. ONE GOOD LITTLE RUN.';
  $('result-clean').textContent = state.hits ? `${state.hits} heavy contact${state.hits === 1 ? '' : 's'}` : 'Clean run';
  $('result-pace').textContent = state.time < 22 ? 'Quayside ace' : state.time < 30 ? 'Smooth sailor' : 'Back safe & sound';
  $('result-tip').textContent = state.hits ? 'A lighter touch on the bends will save you time.' : 'Try lifting just before each turn, then accelerate out.';
  document.querySelector('.race-modal__footnote').textContent = storageAvailable ? 'Best time saved on this browser.' : 'Best time kept for this session. Browser storage is unavailable.';
  ui.best.textContent = `BEST ${formatTime(best)}`; updateHud();
  ui['result-modal'].showModal(); $('retry').focus();
  audio.tone(523.25); audio.tone(659.25, .12); audio.tone(783.99, .24, .35);
}

$('start').addEventListener('click', startRace); $('retry').addEventListener('click', startRace); $('restart-paused').addEventListener('click', startRace);
$('pause').addEventListener('click', pauseRace); $('resume').addEventListener('click', resumeRace);
$('sound').addEventListener('click', () => { audio.start(); audio.enabled = !audio.enabled; $('sound').textContent = audio.enabled ? 'Sound on' : 'Sound off'; $('sound').setAttribute('aria-pressed', String(audio.enabled)); canvas.focus(); });
$('calm').addEventListener('change', event => { calm = event.target.checked; });
ui['pause-modal'].addEventListener('cancel', e => { e.preventDefault(); resumeRace(); });
ui['result-modal'].addEventListener('cancel', e => e.preventDefault());
window.addEventListener('keydown', e => {
  if (e.metaKey || e.ctrlKey || e.altKey) return;
  if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowLeft', 'ArrowDown', 'ArrowRight', 'Space'].includes(e.code)) {
    if (state.phase === 'ready' || state.phase === 'running') { e.preventDefault(); keys.add(e.code); }
  }
  if (e.repeat) return;
  if (e.code === 'KeyR' && state.phase !== 'menu') { e.preventDefault(); startRace(); }
  else if (e.code === 'Enter' && (state.phase === 'menu' || state.phase === 'finished')) { e.preventDefault(); startRace(); }
  else if (e.code === 'Escape' || e.code === 'KeyP') {
    if (state.phase === 'paused') { e.preventDefault(); resumeRace(); }
    else if (state.phase === 'running' || state.phase === 'ready') { e.preventDefault(); pauseRace(); }
  }
});
window.addEventListener('keyup', e => { keys.delete(e.code); });
window.addEventListener('blur', () => { clearInput(); pauseRace(); });
document.addEventListener('visibilitychange', () => { if (document.hidden) { clearInput(); pauseRace(); } });
canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); pauseRace(); $('error').hidden = false; $('error-detail').textContent = 'The graphics connection was interrupted. Reload to get back to the quay.'; });

function onEvent(event) {
  eventLog.push({ ...event, time: Number(state.time.toFixed(4)), speed: Number(state.speed.toFixed(3)), carX: state.x, carZ: state.z });
  if (eventLog.length > 250) eventLog.shift();
  if (event.type === 'start') { message('Find your line.', 1.35); audio.tone(392, 0, .2); }
  if (event.type === 'gate') {
    updateGates(); message(event.gate === 6 ? 'All six. Bring it home!' : `Gate ${String(event.gate).padStart(2, '0')} · clear`, 1.0);
    audio.tone(480 + event.gate * 55, 0, .16); audio.tone(720 + event.gate * 35, .065, .1);
  }
  if (event.type === 'contact') {
    bumpVelocity -= Math.min(.85, event.force * .065);
    pitchVelocity += (Math.sin(state.yaw) * event.nx - Math.cos(state.yaw) * event.nz) * event.force * .14;
    rollVelocity -= (Math.cos(state.yaw) * event.nx + Math.sin(state.yaw) * event.nz) * event.force * .08;
    audio.contact(event.force);
    if (event.force > 4) {
      shake = Math.min(.16, (event.force - 3) * .018); shakeX = event.nx; shakeZ = event.nz;
      const count = Math.min(12, Math.ceil(event.force));
      for (let i = 0; i < count; i++) {
        const chip = world.chips[i]; chip.life = .32 + i * .023; chip.mesh.visible = true;
        chip.mesh.position.set(event.x, .22, event.z); chip.vx = event.nx * 1.5 + Math.sin(i * 8.7) * 1.7; chip.vz = event.nz * 1.5 + Math.cos(i * 4.9) * 1.7; chip.vy = 1.5 + (i % 3) * .55;
      }
    }
  }
  if (event.type === 'finish') finishRace();
}

function updateHud() {
  ui.time.textContent = formatTime(state.time); ui.speed.textContent = String(Math.round(Math.abs(state.speed) * 3.6));
  ui['speed-bar'].style.transform = `scaleX(${Math.min(1, Math.abs(state.speed) / 18)})`;
  ui['drive-state'].textContent = state.phase === 'ready' ? 'READY TO ROLL' : state.speed < -.3 ? 'REVERSE' : input.handbrake || input.brake ? 'BRAKING' : state.slip > 1.2 ? 'AT THE LIMIT' : input.throttle ? 'ON THROTTLE' : 'COASTING';
  if (state.missed && state.phase === 'running') {
    const gate = state.nextGate === 6 ? 'Finish' : `Gate ${state.nextGate + 1}`;
    message(`${gate} missed · turn back, or R to retry`, .2, true); ui['route-hint'].textContent = 'Your gate is behind you';
  } else {
    const hint = state.nextGate === 6 ? 'Through the finish arch' : 'Follow the mint arch';
    if (ui['route-hint'].textContent !== hint) ui['route-hint'].textContent = hint;
  }
}

function animateCar(dt, alpha) {
  const x = previous.x + (state.x - previous.x) * alpha, z = previous.z + (state.z - previous.z) * alpha;
  const yaw = previous.yaw + (state.yaw - previous.yaw) * alpha;
  world.car.position.set(x, 0, z); world.car.rotation.y = -yaw;
  const pitchTarget = clamp(state.accel * .009, -.13, .08), rollTarget = clamp(state.load * .009, -.115, .115);
  pitchVelocity += ((pitchTarget - springPitch) * 85 - pitchVelocity * 12) * dt; springPitch += pitchVelocity * dt;
  rollVelocity += ((rollTarget - springRoll) * 78 - rollVelocity * 10) * dt; springRoll += rollVelocity * dt;
  bumpVelocity += (-bump * 130 - bumpVelocity * 11) * dt; bump += bumpVelocity * dt;
  world.body.rotation.x = springPitch; world.body.rotation.z = springRoll;
  world.body.position.y = bump + Math.sin(state.distance * 2.8) * Math.min(.011, Math.abs(state.speed) * .0008);
  world.tailMat.emissiveIntensity = input.brake || input.handbrake ? 1.5 : .08;
  for (const w of world.wheels) {
    w.steering.rotation.y = w.front ? -state.steer * .51 / (1 + Math.abs(state.speed) * .026) : 0;
    w.wheel.rotation.x -= state.speed / .42 * dt;
    w.steering.position.y = .43 + Math.max(-.04, bump * .3) + springRoll * w.x * .10;
  }
  if (state.phase === 'running' && state.distance - lastSkidDistance > .5 && (state.slip > 1.2 || (input.handbrake && state.speed > 4))) {
    const fx = Math.sin(yaw), fz = -Math.cos(yaw), rx = Math.cos(yaw), rz = Math.sin(yaw);
    for (const side of [-1, 1]) {
      dummy.position.set(x - fx + rx * side * .94, .096, z - fz + rz * side * .94);
      dummy.rotation.set(-Math.PI / 2, 0, -yaw); dummy.scale.set(1, 1, 1); dummy.updateMatrix();
      world.skidMesh.setMatrixAt(skidIndex, dummy.matrix); skidIndex = (skidIndex + 1) % world.skidCapacity;
      world.skidMesh.count = Math.min(world.skidCapacity, world.skidMesh.count + 1);
    }
    world.skidMesh.instanceMatrix.needsUpdate = true; lastSkidDistance = state.distance;
  }
  const gate = GATES[state.nextGate] || FINISH;
  world.routeArrow.visible = state.phase === 'running' && state.missed;
  world.routeArrow.position.set(x + Math.sin(yaw) * 4.5, .13, z - Math.cos(yaw) * 4.5);
  world.routeArrow.rotation.z = Math.atan2(gate.x - world.routeArrow.position.x, gate.z - world.routeArrow.position.z);
}

let accumulator = 0, lastTimestamp = 0;
function frame(timestamp) {
  if (disposed) return;
  const rawDelta = lastTimestamp ? (timestamp - lastTimestamp) / 1000 : 1 / 60; lastTimestamp = timestamp;
  const dt = Math.min(rawDelta, .06);
  if (state.phase === 'running') { frameTimes[frameSample++ % frameTimes.length] = rawDelta * 1000; frameCount++; }
  const moving = state.phase !== 'paused' && state.phase !== 'finished';
  if (moving) visualTime += dt;
  readInput();
  if (state.phase === 'running' || state.phase === 'ready') {
    accumulator += Math.min(rawDelta, .12);
    while (accumulator >= STEP) { syncPrevious(); step(state, input); for (const event of state.events) onEvent(event); accumulator -= STEP; }
  } else accumulator = 0;
  if (moving) {
    animateCar(dt, state.phase === 'menu' ? 1 : accumulator / STEP);
    positionCamera(false, dt); shake *= Math.exp(-12 * dt);
    for (const boat of world.boats) { boat.group.position.y = boat.y + Math.sin(visualTime * .8 + boat.phase) * .045; boat.group.rotation.z = Math.sin(visualTime * .64 + boat.phase) * .012; }
    for (const c of world.chips) {
      if (c.life <= 0) continue; c.life -= dt; c.mesh.visible = c.life > 0; c.vy -= 9 * dt;
      c.mesh.position.x += c.vx * dt; c.mesh.position.y = Math.max(.12, c.mesh.position.y + c.vy * dt); c.mesh.position.z += c.vz * dt;
      c.mesh.rotation.x += dt * 7; c.mesh.rotation.z += dt * 4;
    }
    if (visualTime > calloutUntil) ui.callout.classList.remove('is-visible');
  }
  audio.update(state, input);
  if (timestamp - lastHud > 50) { updateHud(); lastHud = timestamp; }
  world.sunlight.position.set(state.x - 34, 48, state.z + 26); world.sunlight.target.position.set(state.x, 0, state.z - 12);
  renderer.render(scene, camera);
  frameId = requestAnimationFrame(frame);
}
world.car.position.set(0, 0, state.z); positionCamera(true);
frameId = requestAnimationFrame(frame);

// Read-only observations for local proof; there is no teleport, autopilot, or forced finish API.
window.__harbour = Object.freeze({
  snapshot: () => ({ phase: state.phase, x: state.x, z: state.z, yaw: state.yaw, speed: state.speed, steer: state.steer,
    time: state.time, nextGate: state.nextGate, hits: state.hits, missed: state.missed, slip: state.slip, accel: state.accel,
    load: state.load, bodyPitch: springPitch, bodyRoll: springRoll, bump, gateTimes: [...state.gateTimes], best,
    target: { ...(GATES[state.nextGate] || FINISH) }, input: { ...input }, camera: camera.position.toArray(),
    events: eventLog.slice(-30), render: { calls: renderer.info.render.calls, triangles: renderer.info.render.triangles, geometries: renderer.info.memory.geometries, textures: renderer.info.memory.textures } }),
  performance: () => { const times = Array.from(frameTimes.subarray(0, Math.min(frameSample, frameTimes.length))).sort((a, b) => a - b); return { samples: times.length, totalFrames: frameCount, medianMs: times[Math.floor(times.length * .5)] || 0, p95Ms: times[Math.floor(times.length * .95)] || 0, over33Ms: times.filter(t => t > 33.4).length }; },
});
window.addEventListener('pagehide', () => {
  disposed = true; cancelAnimationFrame(frameId); audio.dispose();
  const geometries = new Set(), materials = new Set(), textures = new Set();
  scene.traverse(o => { if (o.geometry) geometries.add(o.geometry); for (const m of o.material ? (Array.isArray(o.material) ? o.material : [o.material]) : []) { materials.add(m); if (m.map) textures.add(m.map); } });
  for (const g of geometries) g.dispose(); for (const m of materials) m.dispose(); for (const t of textures) t.dispose();
  renderer.dispose();
}, { once: true });

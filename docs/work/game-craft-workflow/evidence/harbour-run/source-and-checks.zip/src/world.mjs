import * as THREE from '../vendor/three.module.js';
import { GATES, FINISH, OBSTACLES } from './simulation.mjs';

const COLORS = { ink: 0x21434a, rubber: 0x23383c, cream: 0xf5efd7, concrete: 0xcdd3c3, road: 0x7b9691,
  coral: 0xe66f55, mint: 0x78cdb0, yellow: 0xefba59, metal: 0x809b99, wood: 0xa88a63, water: 0x76b6b3 };

export function buildWorld(scene) {
  const materials = {};
  for (const [name, color] of Object.entries(COLORS)) materials[name] = new THREE.MeshStandardMaterial({ color, roughness: .8, metalness: name === 'metal' ? .28 : .02 });
  const glass = new THREE.MeshStandardMaterial({ color: 0x234b56, roughness: .23, metalness: .24 });
  const cube = new THREE.BoxGeometry(1, 1, 1);
  const cylinder = new THREE.CylinderGeometry(1, 1, 1, 12);
  const batches = new Map();
  const dummy = new THREE.Object3D();
  const add = (geo, mat, x, y, z, sx, sy, sz, ry = 0, rz = 0) => {
    const key = geo.uuid + mat.uuid;
    if (!batches.has(key)) batches.set(key, { geo, mat, items: [] });
    batches.get(key).items.push([x, y, z, sx, sy, sz, ry, rz]);
  };
  const box = (mat, x, y, z, w, h, d, ry = 0, rz = 0) => add(cube, materials[mat] || mat, x, y, z, w, h, d, ry, rz);
  const cyl = (mat, x, y, z, r, h) => add(cylinder, materials[mat], x, y, z, r, h, r);
  const mesh = (geometry, material, parent, x = 0, y = 0, z = 0) => {
    const m = new THREE.Mesh(geometry, material); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; parent.add(m); return m;
  };
  const solid = (w, h, d, r = .08) => roundedBox(w, h, d, r);
  const textTexture = (text, bg, fg, width = 512, height = 160) => {
    const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext('2d'); ctx.fillStyle = bg; ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = `800 ${Math.floor(height * .55)}px Avenir Next, Trebuchet MS, sans-serif`; ctx.fillText(text, width / 2, height / 2 + 3);
    const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = 4; return texture;
  };
  const sign = (text, x, y, z, w, h, bg = '#21434a', fg = '#f5efd7', ry = 0) => {
    const mat = new THREE.MeshStandardMaterial({ map: textTexture(text, bg, fg), roughness: .85 });
    const m = mesh(new THREE.PlaneGeometry(w, h), mat, scene, x, y, z); m.rotation.y = ry; return m;
  };

  scene.background = new THREE.Color(0xc7e1d5);
  scene.fog = new THREE.Fog(0xc7e1d5, 70, 230);
  scene.add(new THREE.HemisphereLight(0xf3f5df, 0x739692, 2.4));
  const sunlight = new THREE.DirectionalLight(0xffecd0, 3.1); sunlight.position.set(-34, 48, 26);
  sunlight.castShadow = true; sunlight.shadow.mapSize.set(2048, 2048);
  Object.assign(sunlight.shadow.camera, { left: -35, right: 35, top: 36, bottom: -36, near: 1, far: 150 });
  sunlight.shadow.bias = -.00025; sunlight.shadow.normalBias = .055;
  scene.add(sunlight, sunlight.target);

  const sea = mesh(new THREE.PlaneGeometry(700, 700), materials.water, scene, 0, -1.35, -80); sea.rotation.x = -Math.PI / 2; sea.castShadow = false;
  mesh(solid(34, 1.75, 205, .3), materials.concrete, scene, 0, -1.03, -86);
  box('cream', 0, -.10, -86, 33.6, .22, 204.5);
  box('road', 0, .035, -86, 21.8, .035, 203);
  for (let z = 12; z > -187; z -= 6) {
    box('concrete', 0, .061, z, 33.6, .012, .04);
    for (const x of [-10.7, 10.7]) box('cream', x, .07, z, .13, .025, 3.3);
  }
  // The racing line is a suggestion; gates remain the authoritative route.
  const routePoints = [new THREE.Vector3(0, .075, 5), ...GATES.map(g => new THREE.Vector3(g.x, .075, g.z)), new THREE.Vector3(0, .075, FINISH.z)];
  const curve = new THREE.CatmullRomCurve3(routePoints);
  const routeLength = curve.getLength();
  for (let d = 4; d < routeLength; d += 3.3) {
    const p = curve.getPointAt(d / routeLength), dir = curve.getTangentAt(d / routeLength);
    box('cream', p.x, .074, p.z, .13, .012, .8, Math.atan2(dir.x, dir.z));
  }
  for (let z = 12; z > -186; z -= 5) {
    for (const side of [-1, 1]) {
      box('cream', side * 16.35, .3, z, .6, .6, 4.9);
      box('yellow', side * 16.36, .63, z, .64, .08, 2.1);
      cyl('ink', side * 16.35, .9, z - 1.8, .19, .55);
      box('ink', side * 16.35, 1.18, z - 1.8, .75, .13, .22);
    }
  }
  box('cream', 0, .3, 15.2, 33.4, .6, .7); box('cream', 0, .3, -187.2, 33.4, .6, .7);
  const fenderGeometry = new THREE.TorusGeometry(.44, .16, 6, 12);
  for (let z = 8; z > -186; z -= 9) for (const side of [-1, 1]) {
    cyl('wood', side * 16.6, -1.6, z, .26, 2.5);
    add(fenderGeometry, materials.rubber, side * 17.15, -.7, z, 1, 1, 1, Math.PI / 2);
  }

  const coneGeometry = new THREE.ConeGeometry(.2, .65, 10);
  const gates = GATES.map((g, i) => {
    const group = new THREE.Group(); group.position.set(g.x, 0, g.z); scene.add(group);
    const liveMat = new THREE.MeshStandardMaterial({ color: i === 0 ? 0x6ff0be : 0xe9e5ca, roughness: .7, emissive: i === 0 ? 0x1d8f65 : 0x000000, emissiveIntensity: .25 });
    for (const side of [-1, 1]) {
      mesh(solid(.27, 4.5, .32, .04), materials.ink, group, side * g.half, 2.25, 0);
      mesh(solid(.37, 2.6, .44, .05), liveMat, group, side * g.half, 1.5, 0);
      mesh(solid(.7, .17, .8, .05), materials.ink, group, side * g.half, .12, 0);
    }
    mesh(solid(g.half * 2 + .42, .42, .4, .08), liveMat, group, 0, 4.6, 0);
    const number = sign(String(i + 1).padStart(2, '0'), g.x, 4.6, g.z + .235, 1.25, .4);
    const stripe = mesh(new THREE.PlaneGeometry(g.half * 2, .46), liveMat, group, 0, .085, 0); stripe.rotation.x = -Math.PI / 2;
    for (const side of [-1, 1]) {
      for (let j = 0; j < 2; j++) {
        const x = g.x + side * (g.half + .7 + j * .8);
        box('ink', x, .08, g.z + 1.2, .5, .09, .5);
        add(coneGeometry, materials.coral, x, .43, g.z + 1.2, 1, 1, 1);
        cyl('cream', x, .41, g.z + 1.2, .13, .12);
      }
    }
    return { group, liveMat, number };
  });

  for (const x of [-8.4, 8.4]) {
    box('ink', x, 2.8, FINISH.z, .32, 5.6, .32);
    box('yellow', x, 2.5, FINISH.z, .39, 2.4, .4);
  }
  box('cream', 0, 5.5, FINISH.z, 17.2, 1.15, .5);
  sign('BACK IN PORT', 0, 5.5, FINISH.z + .27, 8.3, .85);
  for (let j = 0; j < 4; j++) for (let i = 0; i < 20; i++) box((i + j) % 2 ? 'ink' : 'cream', -7.6 + i * .8, .085, FINISH.z + 1.2 - j * .8, .8, .02, .8);
  for (let i = 0; i < 22; i++) box(i % 2 ? 'ink' : 'cream', -10.5 + i, .07, .5, .98, .03, .65);
  sign('ROLL OUT', 0, .091, 2.8, 4.5, 1.4).rotation.x = -Math.PI / 2;

  for (const o of OBSTACLES) {
    if (o.type === 'container') {
      const mat = materials[o.color];
      mesh(solid(o.w, 3.1, o.d, .12), mat, scene, o.x, 1.57, o.z);
      for (let z = o.z - o.d / 2 + .45; z < o.z + o.d / 2; z += .55) {
        box(mat, o.x - o.w / 2 - .035, 1.6, z, .08, 2.9, .12);
        box(mat, o.x + o.w / 2 + .035, 1.6, z, .08, 2.9, .12);
      }
      box('cream', o.x, 1.4, o.z + o.d / 2 + .025, 1.7, .1, .035);
      sign('QUAY', o.x, 2.1, o.z + o.d / 2 + .05, 2, .5, '#' + mat.color.getHexString());
      for (const x of [-.6, .6]) box('metal', o.x + x, 1.6, o.z + o.d / 2 + .075, .05, 2.7, .05);
    } else if (o.type === 'crate') {
      box('wood', o.x, 1, o.z, o.w, 2, o.d);
      for (const side of [-1, 1]) { box('cream', o.x + side * .7, 1, o.z + o.d / 2 + .02, .1, 2, .06); box('cream', o.x, 1, o.z + side * .7, 2.2, 2.02, .1); }
    }
  }
  // Port office on its own loading platform.
  box('concrete', -23, -.7, -10, 12, 1.4, 21);
  mesh(solid(8, 4.8, 11, .15), materials.cream, scene, -23, 2.4, -11);
  box('coral', -23, 4.93, -11, 9, .26, 12);
  for (let z = -14; z < -6; z += 3) { box(glass, -18.98, 2.8, z, .03, 1.7, 1.9); box('ink', -18.9, 1.9, z, .2, .12, 2.2); }
  box('ink', -23, 1.25, -5.46, 1.5, 2.5, .05);
  sign('HARBOUR OFFICE', -23, 3.9, -5.43, 6, .6);
  for (let i = 0; i < 4; i++) box('concrete', -23, .1 * i, -4.7 - .25 * i, 2, .2, .6);
  cyl('ink', -18, 4, 2, .1, 8);
  box('yellow', -17.2, 7.3, 2, 1.5, .8, .05);

  function crane(x, z, flip = 1) {
    box('concrete', x, -.6, z, 13, 1.5, 18);
    for (const dx of [-3, 3]) for (const dz of [-4, 4]) {
      box('yellow', x + dx, 5, z + dz, .65, 10, .65);
      box('ink', x + dx, .5, z + dz, 1.3, .8, 1.3);
    }
    box('yellow', x, 10.4, z, 7.1, .8, 9.2);
    box('yellow', x - flip * 3.5, 11, z, 15, .7, 1.4);
    box('yellow', x + flip * 1.8, 12.5, z, .45, 4, .45);
    box('cream', x + flip * 2.3, 10.9, z + 2.7, 2.1, 2.6, 2.7);
    box(glass, x + flip * 2.3, 11.4, z + 4.07, 1.65, 1, .05);
    for (const dz of [-.4, .4]) box('ink', x - flip * 9, 7.5, z + dz, .045, 6.3, .045);
    box('yellow', x - flip * 9, 4.35, z, 1.1, .38, 1.3);
    for (const dz of [-4, 4]) box('yellow', x, 5, z + dz, .28, 10, .28, 0, .55);
    // Structural stay, not an unattached decoration.
    beam(box, 'ink', new THREE.Vector3(x + flip * 1.8, 14.4, z), new THREE.Vector3(x - flip * 10.5, 11.3, z), .07);
  }
  crane(25, -48); crane(-25, -111, -1);
  for (let i = 0; i < 4; i++) {
    const x = 25 + (i % 2) * 4, z = -88 - Math.floor(i / 2) * 12;
    box(i % 2 ? 'cream' : 'coral', x, 1.3, z, 3.5, 2.6, 10);
    box('concrete', x, -.5, z, 4, 1, 11);
  }
  // Lighthouse gives the last stretch a destination silhouette.
  box('concrete', 24, -1, -177, 13, 1.5, 17);
  const tower = mesh(new THREE.CylinderGeometry(1.6, 2.7, 14, 16), materials.cream, scene, 24, 6, -177);
  cyl('coral', 24, 8.2, -177, 1.93, 2.4); cyl('ink', 24, 13.2, -177, 2.35, .35);
  cyl('yellow', 24, 14.4, -177, 1.4, 2.2);
  const roof = mesh(new THREE.ConeGeometry(2.3, 1.6, 16), materials.coral, scene, 24, 16.3, -177);
  for (let i = 0; i < 8; i++) box('ink', 24 + Math.sin(i * Math.PI / 4) * 1.45, 14.4, -177 + Math.cos(i * Math.PI / 4) * 1.45, .12, 2.2, .12);

  const boats = [];
  function boat(x, z, scale, yaw) {
    const b = new THREE.Group(); b.position.set(x, -.7, z); b.scale.setScalar(scale); b.rotation.y = yaw; scene.add(b);
    mesh(solid(3.7, 1, 8, .65), materials.ink, b, 0, 0, 0);
    mesh(solid(3.4, .3, 7.4, .45), materials.cream, b, 0, .58, 0);
    mesh(solid(2.4, 1.8, 2.6, .12), materials.coral, b, 0, 1.35, .4);
    mesh(solid(2.2, .8, 2.4, .06), glass, b, 0, 2.1, .4);
    mesh(solid(2.7, .15, 2.9, .1), materials.cream, b, 0, 2.57, .4);
    mesh(new THREE.CylinderGeometry(.25, .3, 2.5, 10), materials.yellow, b, 0, 2.6, 2);
    boats.push({ group: b, phase: x * .2, y: -.7 });
  }
  boat(-25, 10, 1.1, .2); boat(30, -129, 1.4, -.15); boat(-38, -64, 1.15, .05);
  // Water flecks are static world geometry; the camera never carries them.
  for (let i = 0; i < 180; i++) {
    const side = i % 2 ? 1 : -1, x = side * (21 + ((i * 13.71) % 105)), z = 40 - ((i * 19.13) % 310);
    box('mint', x, -1.30, z, 1 + (i % 4) * .6, .015, .09);
  }
  // Distant breakwater buildings are quiet, broad silhouettes.
  for (let i = 0; i < 12; i++) box(i % 3 ? 'concrete' : 'cream', -80 + i * 16, 2 + i % 3, -250, 12, 6 + i % 3 * 2, 15);

  for (const { geo, mat, items } of batches.values()) {
    const instanced = new THREE.InstancedMesh(geo, mat, items.length);
    for (let i = 0; i < items.length; i++) {
      const p = items[i]; dummy.position.set(p[0], p[1], p[2]); dummy.scale.set(p[3], p[4], p[5]); dummy.rotation.set(0, p[6], p[7]); dummy.updateMatrix(); instanced.setMatrixAt(i, dummy.matrix);
    }
    instanced.castShadow = true; instanced.receiveShadow = true; instanced.computeBoundingSphere(); scene.add(instanced);
  }

  const car = new THREE.Group(); scene.add(car);
  const body = new THREE.Group(); car.add(body);
  const paint = new THREE.MeshStandardMaterial({ color: COLORS.coral, roughness: .36, metalness: .15 });
  const roofMat = new THREE.MeshStandardMaterial({ color: COLORS.cream, roughness: .42, metalness: .09 });
  mesh(solid(1.93, .44, 3.35, .17), materials.ink, body, 0, .54, 0);
  mesh(solid(1.91, .64, 3.12, .19), paint, body, 0, .83, -.05);
  mesh(solid(1.65, .17, 1.02, .09), paint, body, 0, 1.18, -1.03);
  // A tapered greenhouse gives the compact a connected car silhouette.
  const cab = new THREE.BufferGeometry();
  const v = new Float32Array([
    -.84,1.13,-.66, .84,1.13,-.66, .68,1.83,-.37, -.68,1.83,-.37,
    -.84,1.13,.97, .84,1.13,.97, .68,1.83,.65, -.68,1.83,.65,
  ]);
  cab.setAttribute('position', new THREE.BufferAttribute(v, 3));
  cab.setIndex([0,3,2,0,2,1, 1,2,6,1,6,5, 5,6,7,5,7,4, 4,7,3,4,3,0, 3,7,6,3,6,2]); cab.computeVertexNormals();
  mesh(cab, glass, body);
  mesh(solid(1.53, .16, 1.31, .09), roofMat, body, 0, 1.89, .14);
  for (const side of [-1, 1]) {
    mesh(solid(.11, .68, .09, .02), roofMat, body, side * .76, 1.48, .2);
    mesh(solid(.21, .14, .34, .05), paint, body, side * 1.03, 1.32, -.6);
    mesh(solid(.055, .07, .25, .018), materials.cream, body, side * .966, 1.01, .36);
    const doorNumber = new THREE.Mesh(new THREE.PlaneGeometry(.54, .41), new THREE.MeshStandardMaterial({ map: textTexture('07', '#f5efd7', '#21434a', 128, 96), roughness: .7 }));
    doorNumber.position.set(side * .974, .85, .06); doorNumber.rotation.y = side * Math.PI / 2; body.add(doorNumber);
  }
  mesh(solid(1.84, .15, .18, .06), materials.cream, body, 0, .59, -1.7);
  mesh(solid(1.84, .15, .18, .06), materials.cream, body, 0, .59, 1.65);
  mesh(solid(.7, .15, .035, .02), materials.ink, body, 0, .92, -1.628);
  const headlightMat = new THREE.MeshStandardMaterial({ color: 0xffedbf, emissive: 0xffdd99, emissiveIntensity: .4, roughness: .2 });
  const tailMat = new THREE.MeshStandardMaterial({ color: 0xaf332b, emissive: 0xff3926, emissiveIntensity: .05, roughness: .32 });
  for (const x of [-.65, .65]) {
    mesh(solid(.36, .24, .07, .06), headlightMat, body, x, .93, -1.62);
    mesh(solid(.33, .20, .07, .04), tailMat, body, x, .92, 1.55);
  }
  const plateMat = new THREE.MeshStandardMaterial({ map: textTexture('QUAY 07', '#f5efd7', '#21434a', 256, 80) });
  const plate = mesh(new THREE.PlaneGeometry(.58, .18), plateMat, body, 0, .85, 1.63);
  const wheels = [];
  const tireGeo = new THREE.CylinderGeometry(.42, .42, .29, 20);
  const hubGeo = new THREE.CylinderGeometry(.235, .235, .305, 12);
  for (const x of [-.94, .94]) for (const z of [-1.06, 1.02]) {
    const steering = new THREE.Group(); steering.position.set(x, .43, z); car.add(steering);
    const wheel = new THREE.Group(); steering.add(wheel);
    const tire = mesh(tireGeo, materials.rubber, wheel); tire.rotation.z = Math.PI / 2;
    const hub = mesh(hubGeo, roofMat, wheel); hub.rotation.z = Math.PI / 2;
    for (let i = 0; i < 5; i++) { const spoke = mesh(solid(.017, .35, .045, .008), materials.ink, wheel, Math.sign(x) * .16); spoke.rotation.x = i * Math.PI / 5; }
    wheels.push({ steering, wheel, front: z < 0, x, z });
  }
  const pointerMat = new THREE.MeshBasicMaterial({ color: 0x73efbc, side: THREE.DoubleSide, depthTest: false });
  const arrowShape = new THREE.Shape(); arrowShape.moveTo(0, -.75); arrowShape.lineTo(.7, .3); arrowShape.lineTo(.24, .12); arrowShape.lineTo(.24, .7); arrowShape.lineTo(-.24, .7); arrowShape.lineTo(-.24, .12); arrowShape.lineTo(-.7, .3); arrowShape.closePath();
  const routeArrow = new THREE.Mesh(new THREE.ShapeGeometry(arrowShape), pointerMat); routeArrow.rotation.x = -Math.PI / 2; routeArrow.renderOrder = 2; scene.add(routeArrow);
  const skidCapacity = 180;
  const skidMesh = new THREE.InstancedMesh(new THREE.PlaneGeometry(.16, .65), new THREE.MeshBasicMaterial({ color: 0x365957, transparent: true, opacity: .26, depthWrite: false }), skidCapacity);
  skidMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); skidMesh.count = 0; skidMesh.frustumCulled = false; scene.add(skidMesh);
  const chips = [];
  const chipGeo = new THREE.IcosahedronGeometry(.07, 0);
  for (let i = 0; i < 18; i++) { const m = mesh(chipGeo, materials.cream, scene); m.visible = false; m.castShadow = false; chips.push({ mesh: m, life: 0, vx: 0, vy: 0, vz: 0 }); }
  return { car, body, wheels, tailMat, gates, routeArrow, sunlight, boats, chips, skidMesh, skidCapacity, materials };
}

function beam(box, mat, a, b, width) {
  const delta = b.clone().sub(a), mid = a.clone().add(b).multiplyScalar(.5);
  const length = delta.length(); const angle = Math.atan2(-delta.x, delta.y);
  box(mat, mid.x, mid.y, mid.z, width, length, width, 0, angle);
}

export function roundedBox(w, h, d, r) {
  // ExtrudeGeometry expands the outline by bevelSize. Inset the outline so
  // authored dimensions stay true and attached windows/decals stay outside it.
  r = Math.min(r, w / 2, h / 2, d / 2);
  const bevel = Math.min(r * .45, d * .15, w * .15, h * .15);
  const innerWidth = w - bevel * 2, innerHeight = h - bevel * 2;
  r = Math.max(.001, r - bevel);
  const x = -innerWidth / 2 + r, y = -innerHeight / 2 + r, aw = innerWidth - 2 * r, ah = innerHeight - 2 * r;
  const s = new THREE.Shape();
  s.moveTo(x, y - r); s.lineTo(x + aw, y - r); s.quadraticCurveTo(x + aw + r, y - r, x + aw + r, y);
  s.lineTo(x + aw + r, y + ah); s.quadraticCurveTo(x + aw + r, y + ah + r, x + aw, y + ah + r);
  s.lineTo(x, y + ah + r); s.quadraticCurveTo(x - r, y + ah + r, x - r, y + ah);
  s.lineTo(x - r, y); s.quadraticCurveTo(x - r, y - r, x, y - r);
  const geo = new THREE.ExtrudeGeometry(s, { depth: d - bevel * 2, bevelEnabled: true, bevelSegments: 2, steps: 1, bevelSize: bevel, bevelThickness: bevel, curveSegments: 3 });
  geo.translate(0, 0, -d / 2 + bevel);
  geo.computeBoundingBox();
  const bounds = geo.boundingBox;
  geo.scale(w / (bounds.max.x - bounds.min.x), h / (bounds.max.y - bounds.min.y), d / (bounds.max.z - bounds.min.z));
  geo.computeVertexNormals(); return geo;
}

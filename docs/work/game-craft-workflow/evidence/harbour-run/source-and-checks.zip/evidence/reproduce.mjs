import { chromium } from '/Users/erikhazzard/code/experiments/gizmo/node_modules/playwright/index.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { checkFlows } from './browser-checks.mjs';
import { drive } from './drive.mjs';

const browser = await chromium.launch({ executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless: true });
try {
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  const page = await context.newPage(), errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('http://127.0.0.1:8762/');
  await page.waitForFunction(() => window.__harbour);
  await page.keyboard.press('Enter');
  const flows = await checkFlows(page);
  const run = await drive(page, { label: 'reproduced-run', targetSpeed: 10.4 });
  assert.equal(run.final.phase, 'finished'); assert.equal(run.final.nextGate, 6);
  assert.equal(await page.locator('#result-modal').isVisible(), true);
  const completed = await page.evaluate(() => __harbour.snapshot());
  await page.keyboard.press('Enter');
  const retried = await page.evaluate(() => __harbour.snapshot());
  assert.equal(retried.phase, 'ready'); assert.equal(retried.time, 0); assert.equal(retried.nextGate, 0);
  await page.screenshot({ path: 'evidence/retry.png' });
  await page.reload(); await page.waitForFunction(() => window.__harbour);
  const reloaded = await page.evaluate(() => __harbour.snapshot());
  assert.equal(reloaded.best, completed.best); assert.equal(errors.length, 0);
  const result = { browser: browser.version(), flows, run: { time: completed.time, hits: completed.hits, gates: completed.nextGate, performance: run.performance }, retry: retried, reloaded, errors };
  await fs.writeFile('evidence/final-verification.json', JSON.stringify(result, null, 2));
  console.log(JSON.stringify({ browser: result.browser, flows, run: result.run, retryPassed: true, persistencePassed: true, errors }, null, 2));
} finally { await browser.close(); }

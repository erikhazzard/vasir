import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

export async function checkFlows(page) {
  const results = [], snapshot = () => page.evaluate(() => __harbour.snapshot());
  await page.keyboard.press('r');
  await page.waitForTimeout(220);
  assert.equal((await snapshot()).time, 0);
  assert.equal(await page.locator('#intro-caption').isVisible(), false);
  assert.equal(await page.locator('#intro').isVisible(), false);
  results.push({ name: 'Ready clock stays at zero; intro clears', passed: true });

  await page.keyboard.down('ArrowUp'); await page.waitForTimeout(350);
  const acceleration = await snapshot(); await page.screenshot({ path: 'evidence/ordinary-acceleration.png' });
  await page.waitForTimeout(650); await page.keyboard.down('ArrowLeft'); await page.waitForTimeout(220);
  const loaded = await snapshot(); await page.screenshot({ path: 'evidence/ordinary-steering.png' });
  await page.keyboard.up('ArrowLeft'); await page.keyboard.up('ArrowUp'); await page.waitForTimeout(300);
  const coasting = await snapshot();
  await page.keyboard.down('Space'); await page.waitForTimeout(160);
  const braking = await snapshot(); await page.screenshot({ path: 'evidence/ordinary-braking.png' });
  await page.waitForTimeout(650); await page.keyboard.up('Space');
  const stopped = await snapshot();
  assert.ok(acceleration.bodyPitch > .015); assert.ok(loaded.load < -1); assert.ok(coasting.accel < 0);
  assert.ok(braking.accel < -10); assert.ok(Math.abs(stopped.speed) < .05);
  results.push({ name: 'Arrow keys: acceleration, steering load, coast, Space braking', passed: true, acceleration, loaded, coasting, braking, stopped });

  await page.keyboard.press('Escape'); const paused = await snapshot();
  assert.equal(paused.phase, 'paused');
  await page.keyboard.down('w'); await page.waitForTimeout(250); await page.keyboard.up('w');
  const held = await snapshot();
  assert.deepEqual([held.time, held.x, held.z], [paused.time, paused.x, paused.z]);
  await page.screenshot({ path: 'evidence/pause.png' });
  await page.getByRole('button', { name: 'Back to the run' }).click(); await page.waitForTimeout(100);
  assert.equal((await snapshot()).phase, 'running'); assert.equal((await snapshot()).input.throttle, false);
  await page.keyboard.press('p'); assert.equal((await snapshot()).phase, 'paused');
  await page.keyboard.press('Escape'); assert.equal((await snapshot()).phase, 'running');
  results.push({ name: 'Escape / P pause and resume; clock and position freeze; held input cleared', passed: true });

  await page.keyboard.press('r'); await page.keyboard.down('w'); await page.waitForTimeout(450); await page.keyboard.up('w');
  const tab = await page.context().newPage(); await tab.goto('about:blank'); await tab.bringToFront(); await page.waitForTimeout(160);
  const blurred = await snapshot();
  const nativeBlur = blurred.phase === 'paused';
  if (!nativeBlur) {
    // Headless Chrome can keep both targets focused; explicitly label this wiring check.
    await page.evaluate(() => window.dispatchEvent(new Event('blur')));
  }
  assert.equal((await snapshot()).phase, 'paused');
  await tab.close(); await page.bringToFront();
  results.push({ name: 'Focus loss pauses and clears throttle', passed: true, method: nativeBlur ? 'Native second-tab focus change' : 'Synthetic blur dispatch because headless tab focus did not blur' });

  await page.keyboard.press('r'); await page.keyboard.down('w');
  await page.waitForFunction(() => __harbour.snapshot().missed, null, { timeout: 8000 });
  await page.keyboard.up('w'); const missed = await snapshot();
  assert.equal(missed.nextGate, 0); assert.equal(missed.phase, 'running');
  await page.screenshot({ path: 'evidence/missed-gate.png' });
  await page.keyboard.down('s');
  await page.waitForFunction(() => __harbour.snapshot().z > -15 && __harbour.snapshot().speed < -1, null, { timeout: 10000 });
  await page.keyboard.up('s'); await page.keyboard.down('Space'); await page.waitForTimeout(450); await page.keyboard.up('Space');
  const reversed = await snapshot(); assert.equal(reversed.missed, false); assert.equal(reversed.nextGate, 0);
  assert.equal(await page.locator('#route-hint').innerText(), 'Follow the mint arch');
  await page.screenshot({ path: 'evidence/missed-gate-recovered.png' });
  results.push({ name: 'Missing a gate blocks progress; reverse returns behind it', passed: true, missed, reversed });

  await page.keyboard.press('r'); let fresh = await snapshot();
  assert.equal(fresh.phase, 'ready'); assert.equal(fresh.time, 0); assert.equal(fresh.nextGate, 0); assert.equal(fresh.hits, 0);
  const resources = [];
  for (let i = 0; i < 8; i++) { await page.keyboard.press('r'); await page.waitForTimeout(20); resources.push((await snapshot()).render); }
  assert.ok(new Set(resources.map(r => r.geometries)).size === 1); assert.ok(new Set(resources.map(r => r.textures)).size === 1);
  results.push({ name: 'Restart resets the run and repeated restarts keep GPU resource counts flat', passed: true, resources });

  for (const size of [{ width: 1280, height: 720 }, { width: 1024, height: 576 }]) {
    await page.setViewportSize(size); await page.waitForTimeout(100);
    await page.screenshot({ path: `evidence/landscape-${size.width}.png` });
    const overflow = await page.evaluate(() => ({ width: document.documentElement.scrollWidth > innerWidth, height: document.documentElement.scrollHeight > innerHeight }));
    assert.equal(overflow.width, false); assert.equal(overflow.height, false);
    await page.keyboard.press('Escape');
    const b = await page.locator('#pause-modal').boundingBox(); assert.ok(b.x >= 0 && b.y >= 0 && b.x + b.width <= size.width && b.y + b.height <= size.height);
    await page.screenshot({ path: `evidence/pause-${size.width}.png` }); await page.keyboard.press('Escape');
    results.push({ name: `Landscape ${size.width} × ${size.height}: no scroll; pause controls fit`, passed: true });
  }
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.keyboard.press('r');
  await fs.writeFile('evidence/browser-checks.json', JSON.stringify(results, null, 2));
  return results.map(({ name, passed, method }) => ({ name, passed, method }));
}

// Metres, seconds, radians. The only gameplay clock is this 120 Hz step.
export const STEP = 1 / 120;
export const GATES = Object.freeze([
  { x: -5, z: -20, half: 4.2 }, { x: 5, z: -45, half: 4.2 },
  { x: -5.5, z: -70, half: 4.2 }, { x: 5.5, z: -95, half: 4.2 },
  { x: -4.5, z: -120, half: 4.2 }, { x: 4.5, z: -145, half: 4.2 },
]);
export const FINISH = { x: 0, z: -171, half: 8 };
export const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const approach = (a, b, speed, dt) => a + clamp(b - a, -speed * dt, speed * dt);
export const OBSTACLES = [
  { x: -16.35, z: -86, w: .7, d: 203, type: 'wall' }, { x: 16.35, z: -86, w: .7, d: 203, type: 'wall' },
  { x: 0, z: 15.2, w: 33.4, d: .7, type: 'wall' }, { x: 0, z: -187.2, w: 33.4, d: .7, type: 'wall' },
  { x: -13.3, z: -36, w: 3.3, d: 11, type: 'container', color: 'mint' },
  { x: 13.3, z: -62, w: 3.3, d: 11, type: 'container', color: 'coral' },
  { x: -13.3, z: -87, w: 3.3, d: 11, type: 'container', color: 'yellow' },
  { x: 13.3, z: -112, w: 3.3, d: 11, type: 'container', color: 'mint' },
  { x: -13.3, z: -138, w: 3.3, d: 11, type: 'container', color: 'coral' },
  { x: -12.2, z: -8, w: 2.2, d: 2.2, type: 'crate' },
  { x: 12.8, z: -24, w: 2.2, d: 2.2, type: 'crate' },
  { x: 12.8, z: -155, w: 2.2, d: 2.2, type: 'crate' },
];
export function createState() {
  return { phase: 'menu', resumePhase: 'ready', x: 0, z: 5, yaw: 0, vx: 0, vz: 0, steer: 0, yawRate: 0,
    speed: 0, slip: 0, accel: 0, load: 0, time: 0, nextGate: 0, hits: 0, contactCooldown: 0, reverseWait: 0,
    distance: 0, missed: false, gateTimes: [], events: [] };
}
export function reset(s) { Object.assign(s, createState()); s.phase = 'ready'; }
export function pause(s) { if (s.phase === 'running' || s.phase === 'ready') { s.resumePhase = s.phase; s.phase = 'paused'; } }
export function resume(s) { if (s.phase === 'paused') s.phase = s.resumePhase; }

function collide(s, cx, cz, radius, obstacle, offset) {
  const dx = cx - obstacle.x, dz = cz - obstacle.z;
  const nearX = clamp(dx, -obstacle.w / 2, obstacle.w / 2);
  const nearZ = clamp(dz, -obstacle.d / 2, obstacle.d / 2);
  let nx = dx - nearX, nz = dz - nearZ, dist = Math.hypot(nx, nz), depth = radius - dist;
  if (depth <= 0) return;
  if (dist < .0001) {
    const penX = obstacle.w / 2 - Math.abs(dx), penZ = obstacle.d / 2 - Math.abs(dz);
    if (penX < penZ) { nx = Math.sign(dx) || 1; nz = 0; depth = radius + penX; }
    else { nx = 0; nz = Math.sign(dz) || 1; depth = radius + penZ; }
  } else { nx /= dist; nz /= dist; }
  s.x += nx * depth; s.z += nz * depth;
  const closing = -(s.vx * nx + s.vz * nz);
  if (closing <= 0) return;
  const bounce = closing > 4 ? .14 : .035;
  s.vx += nx * closing * (1 + bounce); s.vz += nz * closing * (1 + bounce);
  s.vx *= .94; s.vz *= .94;
  const torque = (Math.sin(s.yaw) * nz + Math.cos(s.yaw) * nx) * offset;
  s.yawRate += clamp(torque * closing * .10, -.7, .7);
  if (closing > .45 && s.contactCooldown <= 0) {
    if (closing > 3) s.hits++;
    s.events.push({ type: 'contact', force: closing, nx, nz, x: cx - nx * radius, z: cz - nz * radius });
    s.contactCooldown = .22;
  }
}

export function step(s, input, dt = STEP) {
  s.events.length = 0;
  if (s.phase !== 'running' && s.phase !== 'ready') return;
  s.steer = approach(s.steer, input.steer || 0, input.steer ? 4.5 : 6.5, dt);
  if (s.phase === 'ready') {
    if (!input.throttle) return;
    s.phase = 'running'; s.events.push({ type: 'start' });
  }
  s.time += dt;
  s.contactCooldown = Math.max(0, s.contactCooldown - dt);
  const oldX = s.x, oldZ = s.z;
  const fx = Math.sin(s.yaw), fz = -Math.cos(s.yaw), rx = Math.cos(s.yaw), rz = Math.sin(s.yaw);
  let forward = s.vx * fx + s.vz * fz;
  let lateral = s.vx * rx + s.vz * rz;
  const previousForward = forward;
  let engine = 0;
  if (input.throttle) { engine = forward < -.2 ? 12 : 8.6 * Math.max(.06, 1 - Math.max(0, forward) / 21.5); s.reverseWait = 0; }
  else if (input.brake) {
    if (forward > .18) { engine = -15; s.reverseWait = 0; }
    else { s.reverseWait += dt; engine = s.reverseWait > .22 ? -4.8 * Math.max(0, 1 + forward / 5.5) : 0; }
  } else s.reverseWait = 0;
  if (input.handbrake) { engine = -Math.sign(forward) * Math.min(Math.abs(forward) / dt, 18); s.reverseWait = 0; }
  const drag = forward * .20 + forward * Math.abs(forward) * .007;
  forward += (engine - drag) * dt;
  if (input.brake && previousForward > .18 && forward < 0) forward = 0;
  if (!input.throttle && !input.brake && Math.abs(forward) < .07) forward = 0;
  const wheelAngle = s.steer * .51 / (1 + Math.abs(forward) * .026);
  const requestedYaw = Math.tan(wheelAngle) * forward / 2.25;
  const yawLimit = 13.5 / Math.max(4, Math.abs(forward));
  const targetYaw = clamp(requestedYaw, -yawLimit, yawLimit);
  s.yawRate += (targetYaw - s.yawRate) * (1 - Math.exp(-9 * dt));
  // Finite lateral force gives tires grip and a small readable release at speed.
  const grip = input.handbrake ? 7.5 : 13.5;
  lateral += clamp(-lateral * 12, -grip, grip) * dt;
  s.vx = fx * forward + rx * lateral; s.vz = fz * forward + rz * lateral;
  s.yaw += s.yawRate * dt;
  s.x += s.vx * dt; s.z += s.vz * dt;
  for (const o of OBSTACLES) {
    if (Math.abs(s.x - o.x) > o.w / 2 + 2.1 || Math.abs(s.z - o.z) > o.d / 2 + 2.1) continue;
    for (const offset of [-.79, .79]) collide(s, s.x + fx * offset, s.z + fz * offset, .86, o, offset);
  }
  s.speed = s.vx * Math.sin(s.yaw) - s.vz * Math.cos(s.yaw);
  s.slip = Math.abs(s.vx * Math.cos(s.yaw) + s.vz * Math.sin(s.yaw));
  s.accel = clamp((forward - previousForward) / dt, -18, 12);
  s.load = s.yawRate * s.speed;
  s.distance += Math.hypot(s.x - oldX, s.z - oldZ);
  const target = GATES[s.nextGate] || FINISH;
  if (oldZ >= target.z && s.z < target.z) {
    const crossX = oldX + (s.x - oldX) * (oldZ - target.z) / (oldZ - s.z);
    if (Math.abs(crossX - target.x) < target.half - .35) {
      if (s.nextGate < GATES.length) {
        s.nextGate++; s.gateTimes.push(s.time); s.events.push({ type: 'gate', gate: s.nextGate });
      } else { s.phase = 'finished'; s.events.push({ type: 'finish' }); }
    }
  }
  s.missed = s.z < (GATES[s.nextGate] || FINISH).z - 3;
}

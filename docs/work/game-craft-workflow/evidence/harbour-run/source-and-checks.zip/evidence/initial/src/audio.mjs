// Original synthesized sounds. Audio is created only after a user gesture.
export class HarbourAudio {
  enabled = true;
  ctx = null;
  start() {
    if (!this.ctx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      this.ctx = new AudioContext();
      this.master = this.ctx.createGain(); this.master.gain.value = .20; this.master.connect(this.ctx.destination);
      this.engine = this.ctx.createOscillator(); this.engine.type = 'sawtooth';
      this.filter = this.ctx.createBiquadFilter(); this.filter.type = 'lowpass'; this.filter.frequency.value = 280;
      this.engineGain = this.ctx.createGain(); this.engineGain.gain.value = 0;
      this.engine.connect(this.filter).connect(this.engineGain).connect(this.master); this.engine.start();
      this.sub = this.ctx.createOscillator(); this.sub.type = 'sine'; this.subGain = this.ctx.createGain(); this.subGain.gain.value = 0;
      this.sub.connect(this.subGain).connect(this.master); this.sub.start();
      const buffer = this.ctx.createBuffer(1, this.ctx.sampleRate, this.ctx.sampleRate);
      const data = buffer.getChannelData(0); let seed = 19;
      for (let i = 0; i < data.length; i++) { seed = (seed * 16807) % 2147483647; data[i] = seed / 1073741824 - 1; }
      this.noiseBuffer = buffer;
      this.tires = this.ctx.createBufferSource(); this.tires.buffer = buffer; this.tires.loop = true;
      this.tireFilter = this.ctx.createBiquadFilter(); this.tireFilter.type = 'bandpass'; this.tireFilter.frequency.value = 1300; this.tireFilter.Q.value = .7;
      this.tireGain = this.ctx.createGain(); this.tireGain.gain.value = 0;
      this.tires.connect(this.tireFilter).connect(this.tireGain).connect(this.master); this.tires.start();
    }
    this.ctx.resume().catch(() => {});
  }
  update(s, input) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime, active = this.enabled && s.phase === 'running';
    const speed = Math.abs(s.speed), gear = Math.min(3, Math.floor(speed / 5.5));
    const rpm = 42 + (speed - gear * 4) * 7 + (input.throttle ? 12 : 0);
    this.master.gain.setTargetAtTime(this.enabled ? .2 : 0, t, .04);
    this.engine.frequency.setTargetAtTime(rpm, t, .08); this.sub.frequency.setTargetAtTime(rpm * .5, t, .08);
    this.filter.frequency.setTargetAtTime(170 + speed * 23 + (input.throttle ? 160 : 0), t, .09);
    this.engineGain.gain.setTargetAtTime(active ? (input.throttle ? .21 : .11) : 0, t, .08);
    this.subGain.gain.setTargetAtTime(active ? .22 : 0, t, .08);
    this.tireGain.gain.setTargetAtTime(active ? Math.min(.15, Math.max(0, s.slip - .8) * .08 + (input.handbrake && speed > 3 ? .06 : 0)) : 0, t, .06);
  }
  tone(frequency, delay = 0, length = .14) {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime + delay, osc = this.ctx.createOscillator(), gain = this.ctx.createGain();
    osc.type = 'sine'; osc.frequency.value = frequency;
    gain.gain.setValueAtTime(0, t); gain.gain.linearRampToValueAtTime(.24, t + .009); gain.gain.exponentialRampToValueAtTime(.001, t + length);
    osc.connect(gain).connect(this.master); osc.start(t); osc.stop(t + length + .02); osc.onended = () => { osc.disconnect(); gain.disconnect(); };
  }
  contact(force) {
    if (!this.ctx || !this.enabled) return;
    const t = this.ctx.currentTime, src = this.ctx.createBufferSource(), filter = this.ctx.createBiquadFilter(), gain = this.ctx.createGain();
    src.buffer = this.noiseBuffer; filter.type = 'lowpass'; filter.frequency.value = 220 + force * 35;
    gain.gain.setValueAtTime(Math.min(.65, .1 + force * .05), t); gain.gain.exponentialRampToValueAtTime(.001, t + .12 + force * .009);
    src.connect(filter).connect(gain).connect(this.master); src.start(t); src.stop(t + .4); src.onended = () => { src.disconnect(); filter.disconnect(); gain.disconnect(); };
  }
  dispose() { this.ctx?.close().catch(() => {}); }
}

// Browser-only driver: reads observations and issues normal keyboard events.
// It never writes game state. This establishes route reachability, not human playtest quality.
export async function drive(page, { label = 'run', seconds = 40, capture = true, targetSpeed = 11.4 } = {}) {
  const fs = await import('node:fs/promises');
  const timeline = [], held = new Set(); let gate = 0;
  const setKeys = async wanted => {
    for (const key of held) if (!wanted.has(key)) { await page.keyboard.up(key); held.delete(key); }
    for (const key of wanted) if (!held.has(key)) { await page.keyboard.down(key); held.add(key); }
  };
  const start = Date.now();
  while (Date.now() - start < seconds * 1000) {
    const s = await page.evaluate(() => __harbour.snapshot());
    timeline.push({ wallMs: Date.now() - start, phase: s.phase, x: s.x, z: s.z, yaw: s.yaw, speed: s.speed, steer: s.steer,
      nextGate: s.nextGate, time: s.time, slip: s.slip, load: s.load, bodyPitch: s.bodyPitch, bodyRoll: s.bodyRoll, input: s.input });
    if (s.phase === 'finished' || s.phase === 'paused') break;
    if (s.missed) { await setKeys(new Set()); break; }
    const heading = Math.atan2(s.target.x - s.x, s.z - s.target.z);
    const error = Math.atan2(Math.sin(heading - s.yaw), Math.cos(heading - s.yaw));
    const desiredSpeed = targetSpeed - Math.min(4.2, Math.abs(error) * 3);
    const wanted = new Set();
    if (error > .055) wanted.add('d'); else if (error < -.055) wanted.add('a');
    if (s.speed < desiredSpeed) wanted.add('w'); else if (s.speed > desiredSpeed + 1.0) wanted.add('Space');
    await setKeys(wanted);
    if (capture && s.nextGate > gate) { gate = s.nextGate; await page.screenshot({ path: `evidence/${label}-gate-${gate}.png` }); }
    await page.waitForTimeout(85);
  }
  await setKeys(new Set());
  const final = await page.evaluate(() => __harbour.snapshot()), performance = await page.evaluate(() => __harbour.performance());
  if (capture) await page.screenshot({ path: `evidence/${label}-end.png` });
  await fs.writeFile(`evidence/${label}.json`, JSON.stringify({ method: 'Native Playwright keyboard events; read-only feedback, no simulation setters', timeline, final, performance }, null, 2));
  return { final, performance, observations: timeline.length };
}

export async function startRecording(page, label) {
  const fs = await import('node:fs/promises');
  const dir = `evidence/${label}-frames`; await fs.mkdir(dir, { recursive: true });
  const cdp = await page.context().newCDPSession(page), frames = [], writes = [];
  cdp.on('Page.screencastFrame', event => {
    const i = frames.length, file = `${String(i).padStart(5, '0')}.jpg`;
    frames.push({ file, timestamp: event.metadata.timestamp });
    writes.push(fs.writeFile(`${dir}/${file}`, Buffer.from(event.data, 'base64')));
    cdp.send('Page.screencastFrameAck', { sessionId: event.sessionId }).catch(() => {});
  });
  await cdp.send('Page.startScreencast', { format: 'jpeg', quality: 78, maxWidth: 1440, maxHeight: 900, everyNthFrame: 3 });
  return async () => {
    await cdp.send('Page.stopScreencast'); await Promise.all(writes); await cdp.detach();
    const lines = frames.map((f, i) => `file '${f.file}'\nduration ${i + 1 < frames.length ? Math.max(.001, frames[i + 1].timestamp - f.timestamp).toFixed(6) : '0.05'}`).join('\n');
    await fs.writeFile(`${dir}/frames.ffconcat`, `ffconcat version 1.0\n${lines}\nfile '${frames.at(-1).file}'\n`);
    await fs.writeFile(`${dir}/timestamps.json`, JSON.stringify(frames));
    return { frames: frames.length, seconds: frames.at(-1).timestamp - frames[0].timestamp };
  };
}

export async function contactRun(page, label, targetSpeed) {
  const fs = await import('node:fs/promises');
  await page.keyboard.press('r');
  const stop = await startRecording(page, label), timeline = [], held = new Set();
  let contact = null;
  const start = Date.now();
  while (Date.now() - start < 15000) {
    const s = await page.evaluate(() => __harbour.snapshot());
    timeline.push({ wallMs: Date.now() - start, x: s.x, z: s.z, yaw: s.yaw, speed: s.speed, bodyPitch: s.bodyPitch, bodyRoll: s.bodyRoll, bump: s.bump, input: s.input });
    const events = s.events.slice(s.events.findLastIndex(e => e.type === 'restart') + 1);
    contact = events.find(e => e.type === 'contact');
    if (contact) break;
    const heading = Math.atan2(19 - s.x, s.z + 8), error = Math.atan2(Math.sin(heading - s.yaw), Math.cos(heading - s.yaw));
    const wanted = new Set();
    if (error > .06) wanted.add('d'); else if (error < -.06) wanted.add('a');
    if (s.speed < targetSpeed) wanted.add('w'); else if (s.speed > targetSpeed + .5) wanted.add('Space');
    for (const key of held) if (!wanted.has(key)) { await page.keyboard.up(key); held.delete(key); }
    for (const key of wanted) if (!held.has(key)) { await page.keyboard.down(key); held.add(key); }
    await page.waitForTimeout(65);
  }
  for (const key of held) await page.keyboard.up(key);
  await page.screenshot({ path: `evidence/${label}-contact.png` });
  const atContact = await page.evaluate(() => __harbour.snapshot());
  await page.keyboard.down('s'); await page.waitForTimeout(1250); await page.keyboard.up('s');
  const recovered = await page.evaluate(() => __harbour.snapshot());
  await page.keyboard.down('Space'); await page.waitForTimeout(400); await page.keyboard.up('Space');
  await page.screenshot({ path: `evidence/${label}-recovery.png` });
  const recording = await stop(); await page.keyboard.press('Escape');
  const result = { method: 'Native keyboard steering from normal spawn to right wall, then S reverse and Space stop', contact, atContact, recovered, recording, timeline };
  await fs.writeFile(`evidence/${label}.json`, JSON.stringify(result, null, 2));
  return { contact, atContact, recovered, recording };
}

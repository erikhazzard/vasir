import { chromium } from '/Users/erikhazzard/code/experiments/gizmo/node_modules/playwright/index.mjs';
import fs from 'node:fs/promises';
import readline from 'node:readline';
const browser = await chromium.launch({ executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless: true, args: ['--disable-background-timer-throttling', '--disable-renderer-backgrounding'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
const page = await context.newPage();
const errors = [];
page.on('pageerror', e => errors.push(String(e)));
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
await page.goto('http://127.0.0.1:8762');
await page.waitForFunction(() => window.__harbour);
await page.screenshot({ path: 'evidence/initial-title.png' });
Object.assign(globalThis, { browser, context, page, errors, fs });
console.log(JSON.stringify({ ready: true, snapshot: await page.evaluate(() => __harbour.snapshot()), errors }));
const lines = readline.createInterface({ input: process.stdin, terminal: false });
for await (const line of lines) {
  try { const result = await new (Object.getPrototypeOf(async function () {}).constructor)(line)(); console.log(JSON.stringify({ result })); }
  catch (e) { console.log(JSON.stringify({ error: String(e), stack: e.stack })); }
}
await browser.close();

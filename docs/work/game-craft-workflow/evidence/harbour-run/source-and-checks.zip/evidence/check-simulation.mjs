import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { createState, reset, step, pause, resume, GATES, FINISH, STEP } from '../src/simulation.mjs';

const results = [];
function check(name, fn) { const detail = fn(); results.push({ name, passed: true, detail }); }
function ticks(s, count, input) { for (let i = 0; i < count; i++) step(s, input); }
const neutral = { throttle: false, brake: false, handbrake: false, steer: 0 };
function run() {
  const s = createState(); reset(s);
  for (let i = 0; i < 7200 && s.phase !== 'finished'; i++) {
    const target = GATES[s.nextGate] || FINISH;
    const desired = Math.atan2(target.x - s.x, s.z - target.z);
    const error = Math.atan2(Math.sin(desired - s.yaw), Math.cos(desired - s.yaw));
    const speed = 10.5 - Math.min(3, Math.abs(error) * 3);
    step(s, { ...neutral, throttle: s.speed < speed, handbrake: s.speed > speed + .8, steer: error > .06 ? 1 : error < -.06 ? -1 : 0 });
    assert.ok(Number.isFinite(s.x) && Number.isFinite(s.speed));
  }
  return s;
}

check('Repeatable complete route using the public driving inputs', () => {
  const a = run(), b = run();
  assert.equal(a.phase, 'finished'); assert.equal(a.nextGate, 6); assert.ok(a.time < 40); assert.equal(a.hits, 0);
  assert.deepEqual(a, b);
  return { seconds: a.time, gates: a.nextGate, heavyContacts: a.hits };
});
check('A straight run cannot skip the first slalom gate or finish', () => {
  const s = createState(); reset(s); ticks(s, 2400, { ...neutral, throttle: true });
  assert.equal(s.nextGate, 0); assert.equal(s.phase, 'running'); assert.equal(s.missed, true);
  return { z: s.z, nextGate: s.nextGate, phase: s.phase };
});
check('Ready and pause freeze the clock; resume preserves state', () => {
  const s = createState(); reset(s); ticks(s, 600, neutral); assert.equal(s.time, 0);
  ticks(s, 120, { ...neutral, throttle: true }); pause(s); const frozen = [s.x, s.z, s.time];
  ticks(s, 600, { ...neutral, throttle: true, steer: 1 }); assert.deepEqual([s.x, s.z, s.time], frozen);
  resume(s); step(s, neutral); assert.ok(s.time > frozen[2]);
  reset(s); assert.equal(s.time, 0); assert.equal(s.nextGate, 0); assert.equal(s.hits, 0); assert.equal(s.z, 5);
});
check('Braking stops; S can reverse; Space does not drive backwards', () => {
  const s = createState(); reset(s); ticks(s, 240, { ...neutral, throttle: true }); const atSpeed = s.speed;
  ticks(s, 240, { ...neutral, handbrake: true }); assert.ok(Math.abs(s.speed) < .05);
  ticks(s, 240, { ...neutral, brake: true }); assert.ok(s.speed < -1);
  ticks(s, 240, { ...neutral, handbrake: true }); assert.ok(Math.abs(s.speed) < .05);
  return { atSpeed, stoppedSpeed: s.speed };
});
check('Low and strong impacts are distinguished at the same wall', () => {
  // Labelled contact fixtures isolate normal closing speed; browser proof covers reachable contact.
  const forces = [];
  for (const speed of [2, 10]) {
    const s = createState(); reset(s); s.phase = 'running'; s.x = 14; s.z = -12; s.yaw = Math.PI / 2; s.vx = speed;
    let contact;
    for (let i = 0; i < 300; i++) { step(s, neutral); contact ||= s.events.find(e => e.type === 'contact'); }
    assert.ok(contact); assert.ok(s.x < 16); forces.push(contact.force);
  }
  assert.ok(forces[1] > forces[0] * 3);
  return { lightClosingSpeed: forces[0], strongClosingSpeed: forces[1] };
});
await fs.writeFile('evidence/simulation-checks.json', JSON.stringify({ scope: 'Fixed-step integration, not perceptual or browser proof', results }, null, 2));
console.log(JSON.stringify(results, null, 2));

# Harbour Run

The user’s build request authorizes this complete standalone game and its local proof. Desktop landscape and keyboard are the primary surface. No publishing, messages, installs, generated images, or outside implementations.

The play sentence: I lift and turn into the mint gate; the front wheels lead and the body loads over the tires; clearing the arch reveals the next line; I accelerate out and try to carry a little more speed next time.

Six alternating gates on a 180 metre dockyard sprint. The time starts on acceleration and ends only after all six gates and the finish in order. A missed gate costs time and can be recovered by reversing/turning back or restarting. There is no artificial timeout. Results show completion time, local best, and heavy contacts. Retry returns immediately to the same course.

Original miniature 3D art: ivory concrete, dark desaturated quay pavement, teal water, coral compact car, cream roof, dark rubber, yellow dock machinery. The current mint gate is the most legible world signal. Broad geometry and repeated bevel widths tie car and scenery together. Landmarks progress from the port office to container stacks, cargo crane, and lighthouse finish.

Camera: elevated perspective follow, car in the lower centre with two-gate anticipation, restrained velocity lookahead and eased yaw. Desktop goal: smooth 60 Hz presentation on the available Chrome environment, 120 Hz authored vehicle simulation. One renderer, one scene submission per frame, one directional shadow map, no postprocessing. Static repeated geometry is instanced. Main thread is appropriate for one body, a dozen primitive obstacles, and a bounded static scene; a worker would add coordination without a useful workload to move.

Vehicle: throttle torque tapers with speed; S brakes then reverses, Space only brakes; steering returns when released and becomes less sharp at speed; finite lateral grip permits mild slip. Visual suspension expresses acceleration/braking and turn load. Contact feedback uses normal closing speed, with light compression versus a larger rebound and road-local chips on stronger collisions. Wheels remain attached and effects never delay input. Calm camera removes impact displacement.

Shell: toy-like club timing ticket, warm paper surfaces, ink typography, yellow primary buttons. Offline installed font stacks with display/body hierarchy and monospaced numerals. Blocks are harbour-intro, race-hud, race-clock, race-route, race-speed, race-modal, race-result, and ui-button. A brief opacity acknowledgment follows a gate; time and route remain stable. Vanilla semantic DOM; the workspace does not contain the Studio UI kit or canonical spec/template files, so their repository-specific integration does not apply.

Workflow: game__orchestrating-playable-build owns play → diagnose → repair → compare; game__art-directing governs active-play relationships; game__adding-juice governs response range and recovery; code__threejs-rapier-performance guards the frame/tick owners; design__building-frontend-interfaces and design__implementing-frontend-css-html govern the shell. The Studio spec/template skills were inspected, but their canonical format and template inventory are absent. No fallback Studio spec or external template is imported.

Proof: actual Chrome canvas with native keyboard events, full ordered finish and retry, ordinary accelerate/steer/coast/brake contrasts, low and stronger collision recovery, missed gate, pause/resume, focus-loss pause, reload persistence, and landscape layout checks. Preserve the initial build and any repair comparison in evidence/. Quality judgment must distinguish functional proof, observed frames/timing, motion observation, and human taste acceptance.

# Harbour Run

A complete desktop landscape driving time trial. Thread six gates in order, cross the finish, then chase your best time.

The normal entrypoint is **`index.html`**. From this workspace:

```sh
python3 -m http.server 8762 --bind 127.0.0.1
```

Open **http://127.0.0.1:8762/** in Chrome with graphics acceleration enabled. Serve over HTTP; opening the HTML directly as a file will block module imports. No build step, package installation, or internet connection is needed.

| Control | Action |
| --- | --- |
| W / ↑ | Accelerate |
| A, D / ←, → | Steer |
| S / ↓ | Brake, then reverse |
| Space | Brake without reversing |
| Escape / P | Pause or resume |
| R | Restart immediately |
| Enter | Start from the title; retry from results |

The clock starts when you accelerate. Clear the mint arch before the next gate counts. If you miss one, reverse or turn back, or press R to retry. Collisions cost speed; there are no hidden time penalties. Best time is stored in this browser when local storage is available. Sound and calm-camera controls are in the game.

The game uses the supplied Three.js modules, original geometry/materials, synthesized audio, and a fixed-step arcade vehicle model. The course is flat, authored, and deliberately short. Gate posts, crates, containers, and quay barriers collide; cones and boats are scenery.

Implementation: `src/simulation.mjs` owns gameplay; `src/world.mjs` owns the scene and car; `src/main.mjs` owns input, presentation, and the one frame loop; `src/audio.mjs` owns synthesized sound.

Read the [quality evaluation](evidence/QUALITY.md) or open the [evidence viewer](evidence/index.html). The initial source is retained in `evidence/initial/` for comparison. It is an earlier build with documented defects, not the normal entrypoint.

Local proof, using the already-installed browser tools:

```sh
node evidence/check-simulation.mjs
node evidence/reproduce.mjs
```

The browser proof uses ordinary keyboard events and read-only observations. It does not teleport the car or force a result. Browser captures and integration checks establish the observed local behavior; they do not substitute for a human handling playtest or testing on other hardware.

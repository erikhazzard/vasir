import { chromium } from '/Users/erikhazzard/code/experiments/gizmo/node_modules/playwright/index.mjs';
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, rm } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';

const rules = JSON.parse(await readFile('evidence/rules-proof.json', 'utf8'));
const browser = await chromium.launch({ executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless: true });
const checks = [], inputs = [], errors = [];
const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
const page = await context.newPage();
page.on('pageerror', error => errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
const cell = index => page.locator(`.ceramic-tile[data-index="${index}"]`);
const state = () => page.evaluate(() => ({
  turns: +document.getElementById('turn-count').textContent,
  orientations: [...document.querySelectorAll('.ceramic-tile')].map(x => +x.dataset.turn),
  wet: [...document.querySelectorAll('.ceramic-tile')].filter(x => x.dataset.wet === 'true').map(x => +x.dataset.index),
  solved: document.getElementById('board').dataset.solved === 'true',
  status: document.getElementById('status-title').textContent,
  focus: document.activeElement?.dataset.index
}));
async function capture(name, fullPage = false) { await page.screenshot({ path: `evidence/${name}.png`, fullPage }); }
async function click(index, reverse = false, wait = 480) {
  await cell(index).click({ modifiers: reverse ? ['Shift'] : [] });
  inputs.push({ kind: reverse ? 'shift-click' : 'click', index, state: await state() });
  await page.waitForTimeout(wait);
}
async function press(key, wait = 120) {
  await page.keyboard.press(key);
  inputs.push({ kind: 'key', key, state: await state() });
  if (wait) await page.waitForTimeout(wait);
}
async function record(name) {
  const directory = `evidence/${name}-frames`;
  await mkdir(directory, { recursive: true });
  const client = await context.newCDPSession(page);
  const frames = [], writes = [];
  client.on('Page.screencastFrame', frame => {
    const filename = `frame-${String(frames.length).padStart(5, '0')}.jpg`;
    frames.push({ filename, timestamp: frame.metadata.timestamp });
    writes.push(writeFile(`${directory}/${filename}`, Buffer.from(frame.data, 'base64')));
    client.send('Page.screencastFrameAck', { sessionId: frame.sessionId }).catch(() => {});
  });
  await client.send('Page.startScreencast', { format: 'jpeg', quality: 85, maxWidth: 1440, maxHeight: 900, everyNthFrame: 1 });
  return async () => {
    await client.send('Page.stopScreencast');
    await Promise.all(writes);
    await writeFile(`${directory}/timing.json`, JSON.stringify(frames, null, 2));
    const concat = frames.map((frame, index) => `file '${frame.filename}'\nduration ${index < frames.length - 1 ? Math.max(.01, frames[index + 1].timestamp - frame.timestamp) : .6}`).join('\n');
    await writeFile(`${directory}/frames.txt`, concat + `\nfile '${frames.at(-1).filename}'\n`);
    const encoded = spawnSync('/opt/homebrew/bin/ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', `${directory}/frames.txt`, '-vf', 'fps=30', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', `evidence/${name}.mp4`], { encoding: 'utf8' });
    assert.equal(encoded.status, 0, encoded.stderr);
    await writeFile(`evidence/${name}-timing.json`, JSON.stringify(frames, null, 2));
    await rm(directory, { recursive: true });
    await client.detach();
    return { frames: frames.length, duration: frames.at(-1).timestamp - frames[0].timestamp };
  };
}

try {
  await page.goto('http://127.0.0.1:8761');
  await page.waitForTimeout(400);
  const opening = await state();
  assert.equal(opening.solved, false);
  assert.equal(opening.turns, 0);
  assert.deepEqual(opening.wet, [0,6]);
  await capture('final-desktop-1440x900');
  const stopRecording = await record('played-mouse-route');

  // Exploratory wrong turn: water enters B2, then C2 sends it to a left-edge dead end.
  await click(7);
  assert.deepEqual((await state()).wet, [0,6,7]);
  await capture('played-first-choice');
  await click(13);
  assert.deepEqual((await state()).wet, [0,6,7,12,13], 'The tempting lower branch runs into the board edge');
  assert.equal((await state()).solved, false);
  await capture('played-misleading-branch');
  await page.getByRole('button', { name: /^Undo/ }).click();
  await page.waitForTimeout(320);
  assert.equal((await state()).turns, 1);
  await page.getByRole('button', { name: /^Reset/ }).click();
  await page.waitForTimeout(320);
  assert.deepEqual((await state()).orientations, opening.orientations);
  await page.getByRole('button', { name: /^Undo/ }).click();
  await page.waitForTimeout(320);
  assert.equal((await state()).turns, 1, 'Undo recovers a reset');
  checks.push('Wrong branch fills to a dead end; undo reverses a turn and recovers reset');

  // Route is reached exclusively with real pointer inputs; data is read-only.
  for (const index of [4, ...rules.route]) {
    let diff = (rules.solution[index] - (await state()).orientations[index] + 4) % 4;
    if (diff === 3) await click(index, true);
    else for (let step = 0; step < diff; step++) await click(index);
    if (index === 14) await capture('played-upper-loop');
    if (index === 21) await capture('played-lower-loop');
    if (index === 11) await capture('played-near-basin');
  }
  await page.waitForTimeout(1100);
  const solved = await state();
  assert.equal(solved.solved, true);
  assert.equal(solved.wet.length, 21);
  assert.equal(await page.getByRole('button', { name: /Play again/ }).count(), 1);
  await capture('solved-desktop');
  const completedTile = await cell(7).boundingBox();
  // A real pointer can still land on an aria-disabled tile. Avoid Playwright's
  // intentional enabled-state wait while checking the game's actual response.
  await page.mouse.click(completedTile.x + completedTile.width / 2, completedTile.y + completedTile.height / 2);
  assert.deepEqual(await state(), { ...solved, focus: '7' }, 'The solved board holds its arrangement');
  await page.getByRole('button', { name: /^Undo/ }).click();
  await page.waitForTimeout(350);
  assert.equal((await state()).solved, false);
  await capture('undo-from-solved');
  await click(23);
  assert.equal((await state()).solved, true);
  await page.getByRole('button', { name: /Play again/ }).click();
  await page.waitForTimeout(400);
  assert.deepEqual((await state()).orientations, opening.orientations);
  assert.equal((await state()).turns, 0);
  checks.push('Complete 18-tile mouse route; two wet dead ends; stable solved board; undo and play again');
  const mouseVideo = await stopRecording();
  console.log(JSON.stringify({ milestone: 'Mouse route completed', mouseVideo }));

  // Entire second solve uses Tab, arrows, Enter, Space, and Shift+Enter.
  await page.reload();
  await press('Tab');
  await press('Tab');
  assert.equal((await state()).focus, '7');
  await capture('keyboard-focus');
  await press('Shift+Enter');
  await press('u');
  assert.deepEqual((await state()).orientations, opening.orientations);
  const keyboardStart = inputs.length;
  for (const [position, index] of [4, ...rules.route].entries()) {
    let focused = +(await state()).focus;
    while (Math.floor(focused / 6) !== Math.floor(index / 6)) { await press(index > focused ? 'ArrowDown' : 'ArrowUp', 0); focused = +(await state()).focus; }
    while (focused % 6 !== index % 6) { await press(index % 6 > focused % 6 ? 'ArrowRight' : 'ArrowLeft', 0); focused = +(await state()).focus; }
    const diff = (rules.solution[index] - (await state()).orientations[index] + 4) % 4;
    if (diff === 3) await press('Shift+Enter', 280);
    else for (let step = 0; step < diff; step++) await press(position % 2 ? 'Space' : 'Enter', 280);
  }
  await page.waitForTimeout(800);
  assert.equal((await state()).solved, true);
  await capture('solved-keyboard');
  assert.ok(inputs.slice(keyboardStart).every(input => input.kind === 'key'));
  await press('Control+z');
  assert.equal((await state()).solved, false);
  await press('Meta+z');
  await press('r');
  assert.deepEqual((await state()).orientations, opening.orientations);
  await press('u');
  assert.ok((await state()).turns > 0);
  checks.push('Complete keyboard-only solve; Space/Enter parity; reverse turn; Ctrl/Cmd+Z; R and undo reset');
  console.log(JSON.stringify({ milestone: 'Keyboard route completed' }));

  // Repeated immediate commands and an early undo cannot leave stale movement.
  await page.reload();
  await cell(7).focus();
  for (let i = 0; i < 12; i++) await press('Enter', 0);
  assert.equal((await state()).orientations[7], opening.orientations[7]);
  assert.equal((await state()).turns, 12);
  await press('u', 0);
  await press('r', 0);
  await page.waitForTimeout(350);
  assert.deepEqual((await state()).orientations, opening.orientations);
  assert.equal(await page.locator('.is-moving').count(), 0);
  await press('Home');
  await press('ArrowLeft');
  assert.equal((await state()).focus, '6');
  await press('ArrowUp');
  await press('ArrowUp');
  assert.equal((await state()).focus, '0');
  await press('Tab');
  assert.notEqual((await state()).focus, '0', 'Keyboard can leave the board');
  checks.push('Twelve rapid turns, undo during motion, reset, no stale animations, clamped arrows, Tab exit');

  const layouts = [];
  for (const [width, height] of [[1440,1000],[1280,800],[1024,768],[820,680],[768,600],[390,844],[360,740],[320,640]]) {
    await page.setViewportSize({ width, height });
    await page.reload();
    await page.waitForTimeout(180);
    const layout = await page.evaluate(() => {
      const tile = document.querySelector('.ceramic-tile').getBoundingClientRect();
      const board = document.getElementById('board').getBoundingClientRect();
      const status = document.getElementById('flow-status').getBoundingClientRect();
      return { viewport: [innerWidth,innerHeight], scrollWidth: document.documentElement.scrollWidth, scrollHeight: document.documentElement.scrollHeight, tileWidth: tile.width, board: board.toJSON(), status: status.toJSON(), allTilesInWidth: [...document.querySelectorAll('.ceramic-tile')].every(x => { const b=x.getBoundingClientRect(); return b.left >= 0 && b.right <= innerWidth; }) };
    });
    assert.equal(layout.scrollWidth, width, `No horizontal overflow at ${width}`);
    assert.equal(layout.allTilesInWidth, true);
    await capture(`final-${width}x${height}`, width <= 820);
    await click(7, false, 100);
    assert.equal((await state()).turns, 1);
    layouts.push(layout);
  }
  checks.push('Playable at 1440, 1280, 1024, 820, 768, 390, 360 and 320 CSS-pixel widths; no horizontal clipping');

  await context.close();
  const touch = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true, reducedMotion: 'reduce' });
  const touchPage = await touch.newPage();
  await touchPage.goto('http://127.0.0.1:8761');
  await touchPage.locator('.ceramic-tile[data-index="7"]').tap();
  assert.equal(await touchPage.locator('#turn-count').textContent(), '01');
  assert.equal(await touchPage.locator('.ceramic-tile__piece').first().evaluate(e => getComputedStyle(e).transitionDuration), '0s');
  await touchPage.getByRole('button', { name: /^Undo/ }).tap();
  assert.equal(await touchPage.locator('#turn-count').textContent(), '00');
  await touchPage.screenshot({ path: 'evidence/final-mobile-390x844.png' });
  await touch.close();
  checks.push('Touch-emulated tap and undo at 390 × 844; reduced-motion transforms disabled');

  const direct = await browser.newPage();
  await direct.goto(new URL('../index.html', import.meta.url).href);
  await direct.locator('.ceramic-tile[data-index="7"]').click();
  assert.equal(await direct.locator('#turn-count').textContent(), '01');
  await direct.close();
  checks.push('Normal index.html entrypoint works directly through file://');
  assert.deepEqual(errors, []);
  await writeFile('evidence/browser-proof.json', JSON.stringify({ checks, layouts, mouseVideo, errors, inputs }, null, 2));
  console.log(JSON.stringify({ passed: checks, errors, layouts: layouts.map(x => ({ viewport: x.viewport, tileWidth: x.tileWidth, scrollHeight: x.scrollHeight })) }));
} catch (error) {
  await writeFile('evidence/browser-proof-failure.json', JSON.stringify({ error: error.stack, checks, errors, inputs }, null, 2));
  throw error;
} finally {
  await browser.close();
}

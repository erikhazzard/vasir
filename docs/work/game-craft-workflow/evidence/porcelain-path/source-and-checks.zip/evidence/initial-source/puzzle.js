/* Pure board rules. Classic script keeps the normal entrypoint usable via file://. */
(() => {
  const N = 1, E = 2, S = 4, W = 8;
  const rows = 5, columns = 6;
  const shapes = { elbow: N | E, straight: N | S, tee: N | E | W, end: N };
  // Clockwise quarter-turns from the canonical shape. Authored, never randomized.
  const tiles = [
    ['end', 2], ['elbow', 3], ['elbow', 0], ['end', 1], ['elbow', 0], ['elbow', 2],
    ['tee', 0], ['elbow', 1], ['straight', 1], ['end', 2], ['tee', 2], ['elbow', 0],
    ['straight', 1], ['elbow', 2], ['elbow', 1], ['elbow', 0], ['elbow', 1], ['straight', 1],
    ['straight', 1], ['elbow', 3], ['elbow', 0], ['straight', 1], ['end', 3], ['elbow', 3],
    ['end', 0], ['end', 1], ['elbow', 2], ['elbow', 1], ['elbow', 0], ['straight', 1]
  ].map(([shape, initial]) => Object.freeze({ shape, initial }));
  const directions = [
    { bit: N, opposite: S, dr: -1, dc: 0, name: 'up' },
    { bit: E, opposite: W, dr: 0, dc: 1, name: 'right' },
    { bit: S, opposite: N, dr: 1, dc: 0, name: 'down' },
    { bit: W, opposite: E, dr: 0, dc: -1, name: 'left' }
  ];
  function maskAt(index, turns) {
    let mask = shapes[tiles[index].shape];
    for (let i = 0, count = ((turns % 4) + 4) % 4; i < count; i++) mask = ((mask << 1) & 15) | (mask >> 3);
    return mask;
  }
  function neighbor(index, direction) {
    const row = Math.floor(index / columns) + direction.dr;
    const column = index % columns + direction.dc;
    return row < 0 || row >= rows || column < 0 || column >= columns ? -1 : row * columns + column;
  }
  function trace(turns) {
    const masks = turns.map((turn, index) => maskAt(index, turn));
    const wet = new Set();
    const distance = new Map();
    const queue = [];
    if (masks[6] & W) { wet.add(6); distance.set(6, 0); queue.push(6); }
    for (let head = 0; head < queue.length; head++) {
      const index = queue[head];
      for (const direction of directions) {
        if (!(masks[index] & direction.bit)) continue;
        const next = neighbor(index, direction);
        if (next < 0 || !(masks[next] & direction.opposite) || wet.has(next)) continue;
        wet.add(next); distance.set(next, distance.get(index) + 1); queue.push(next);
      }
    }
    return { masks, wet, distance, solved: wet.has(23) && Boolean(masks[23] & E) };
  }
  window.PorcelainPuzzle = Object.freeze({ rows, columns, tiles: Object.freeze(tiles), directions, maskAt, neighbor, trace });
})();

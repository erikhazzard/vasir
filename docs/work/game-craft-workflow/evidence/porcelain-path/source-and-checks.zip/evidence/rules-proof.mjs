import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import vm from 'node:vm';
const scope = { window: {} };
vm.runInNewContext(await readFile('puzzle.js', 'utf8'), scope);
const puzzle = scope.window.PorcelainPuzzle;
const initial = Array.from(puzzle.tiles, t => t.initial);
const solution = [...initial];
const route = [6, 7, 1, 2, 8, 14, 13, 19, 20, 26, 27, 21, 15, 16, 10, 11, 17, 23];
const solutionTurns = { 6:0, 7:3, 1:1, 2:2, 8:0, 14:3, 13:1, 19:0, 20:2, 26:0, 27:3, 21:0, 15:1, 16:3, 10:1, 11:2, 17:0, 23:0, 4:2, 3:1 };
for (const [index, turn] of Object.entries(solutionTurns)) solution[index] = turn;
assert.equal(puzzle.trace(initial).solved, false, 'Opening must remain unsolved');
assert.equal(puzzle.trace(solution).solved, true, 'Authored route reaches the basin');
assert.ok(route.every(index => puzzle.trace(solution).wet.has(index)));
assert.equal(puzzle.trace(solution).wet.size, 21, 'Two side branches flow with the 18-tile route');

// Independent simple-route search, without the target turns or runtime flood fill.
const basePorts = { elbow: [0, 1], straight: [0, 2], tee: [0, 1, 3], end: [0] };
const canJoin = (index, entry, exit) => [0,1,2,3].some(rotation => {
  const ports = basePorts[puzzle.tiles[index].shape].map(port => (port + rotation) % 4);
  return ports.includes(entry) && ports.includes(exit);
});
const offsets = [-6, 1, 6, -1];
const paths = [];
function search(index, entry, path) {
  if (index === 23 && canJoin(index, entry, 1)) { paths.push([...path]); return; }
  for (let exit = 0; exit < 4; exit++) {
    if (exit === entry || !canJoin(index, entry, exit)) continue;
    if (exit === 0 && index < 6 || exit === 2 && index >= 24 || exit === 1 && index % 6 === 5 || exit === 3 && index % 6 === 0) continue;
    const next = index + offsets[exit];
    if (path.includes(next)) continue;
    search(next, (exit + 2) % 4, [...path, next]);
  }
}
search(6, 3, [6]);
assert.ok(paths.some(path => path.join(',') === route.join(',')), 'Independent solver discovers the intended route');
for (const index of route) {
  const disconnected = [...solution];
  disconnected[index] += 1;
  if (puzzle.tiles[index].shape !== 'tee') assert.equal(puzzle.trace(disconnected).solved, false, `Breaking ${index} must interrupt the route`);
}
const report = { initialWet: Array.from(puzzle.trace(initial).wet), solutionWet: Array.from(puzzle.trace(solution).wet), route, solution, solutionTurns, independentRouteCount: paths.length, shortestRouteLength: Math.min(...paths.map(p => p.length)), routes: paths };
await writeFile('evidence/rules-proof.json', JSON.stringify(report, null, 2));
console.log(JSON.stringify(report));

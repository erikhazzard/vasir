import { chromium } from '/Users/erikhazzard/code/experiments/gizmo/node_modules/playwright/index.mjs';
import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';

const browser = await chromium.launch({ executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless: true });
const page = await browser.newPage({ viewport: { width: 820, height: 680 } });
const layouts = [];
try {
  for (const [width, height] of [[1440,1000],[1280,800],[1024,768],[820,680],[768,600],[768,1024],[390,844],[360,740],[320,640]]) {
    await page.setViewportSize({ width, height });
    await page.goto('http://127.0.0.1:8761');
    await page.waitForTimeout(100);
    const layout = await page.evaluate(() => {
      const box = selector => document.querySelector(selector).getBoundingClientRect().toJSON();
      return { viewport: [innerWidth, innerHeight], scrollWidth: document.documentElement.scrollWidth, scrollHeight: document.documentElement.scrollHeight, tileWidth: box('.ceramic-tile').width, board: box('#board'), controls: box('.puzzle-controls'), status: box('#flow-status'), allTilesInWidth: [...document.querySelectorAll('.ceramic-tile')].every(e => {const b=e.getBoundingClientRect(); return b.left>=0 && b.right<=innerWidth;}) };
    });
    assert.equal(layout.scrollWidth, width);
    assert.ok(layout.allTilesInWidth);
    if (width === 820 || width === 768 && height === 600) assert.ok(layout.controls.bottom <= height, 'Landscape board and recovery controls share the viewport');
    if (width === 390) assert.ok(layout.tileWidth >= 44);
    await page.screenshot({ path: `evidence/final-${width}x${height}.png`, fullPage: width <= 820 });
    await page.locator('.ceramic-tile[data-index="7"]').click();
    assert.equal(await page.locator('#turn-count').textContent(), '01');
    await page.getByRole('button', { name: /^Undo/ }).click();
    assert.equal(await page.locator('#turn-count').textContent(), '00');
    layouts.push(layout);
  }
  const report = JSON.parse(await readFile('evidence/browser-proof.json', 'utf8'));
  report.layouts = layouts;
  report.checks.push('Post-repair responsive check: landscape board and recovery controls visible together at 820 × 680 and 768 × 600; portrait 768 × 1024 stacks naturally');
  await writeFile('evidence/browser-proof.json', JSON.stringify(report, null, 2));
  await writeFile('evidence/responsive-proof.json', JSON.stringify(layouts, null, 2));
  console.log(JSON.stringify(layouts.map(x => ({ size: x.viewport, boardBottom: x.board.bottom, controlsBottom: x.controls.bottom, scrollHeight: x.scrollHeight }))));
} finally { await browser.close(); }

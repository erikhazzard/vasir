# Porcelain Path

A calm, untimed, desktop-first puzzle. Turn matte ceramic tiles to carry water from the spring to the basin. One original authored 6 × 5 board, with a winding route and misleading branches.

Open `index.html` directly, or serve this folder with `python3 -m http.server 8761 --bind 127.0.0.1` and visit `http://127.0.0.1:8761`.

Click a tile to turn clockwise; Shift-click turns back. Tab into the board, use arrow keys to choose a tile, and Enter or Space to turn it. Shift reverses the turn. U or Ctrl/Cmd+Z undoes; R resets while the board has focus. Both actions also have visible buttons. Reset is undoable. Completion holds the finished arrangement; undo reopens play.

No dependencies, downloads, network calls, generated images, or build step. Art is original SVG and CSS. Progress lasts for the current page session. Refresh starts over.

## Design contract

- **Play sentence:** I turn a tile; its channel changes direction and the water follows any matching openings; I inspect the new reach and choose the next turn.
- **Look:** ceramic workshop / quiet editorial composition. Warm limestone, flecked ivory, recessed sand-colored channels, muted blue water, small terracotta marks. Shared upper-left light and soft contact shadows.
- **Type:** local Iowan Old Style / Palatino display and Avenir Next / Trebuchet body stacks. A restrained 12 / 14 / 17 / 22 / 64 scale. No font requests.
- **Composition:** title and instructions at left, large landscape board at right; stack the board before the detailed instructions on narrow screens. All state changes preserve the board position.
- **Motion:** a rigid quarter-turn, approximately 240 ms with a quick onset and weighted settling. Newly connected channels fill locally. Completion fills the basin without covering the path. Reduced motion retains state with immediate turns.
- **Rules:** water traverses mutually facing openings. Reaching the basin is sufficient; unused tiles and open side branches are permitted. There is no timer, score, move limit, or penalty.
- **Component contract:** `porcelain-game` (page), `game-intro`, `game-guide`, `puzzle-stage`, `ceramic-board`, `ceramic-tile` (wet / complete, exposed in its accessible name), `water-port` (spring / basin, full), `flow-status` (complete), `puzzle-controls`, and shared `ui-button` (primary).

## Workflow and proof

Uses the installed Vasir playable-build orchestration, art direction, game feel, frontend implementation, and first-playable comprehension guidance. This standalone workspace contains skills, not a Studio runtime or canonical Studio spec/template. The local HTML/CSS/JS substrate follows the creator's explicit brief; no other implementations or templates were consulted. Desktop landscape and original procedural/vector art override the skills' generic portrait and external font/image defaults.

Play observations, screenshots, repeatable browser proof, and any initial/repaired comparisons are in `evidence/`. See `evidence/review.md` for the qualified handoff judgment.

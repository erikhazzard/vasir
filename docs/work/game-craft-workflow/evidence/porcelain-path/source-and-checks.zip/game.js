(() => {
  'use strict';
  const puzzle = window.PorcelainPuzzle;
  const $ = (id) => document.getElementById(id);
  const board = $('board');
  const initial = puzzle.tiles.map((tile) => tile.initial);
  let turns = [...initial];
  const angles = turns.map((turn) => turn * 90);
  let moveCount = 0;
  let selected = 7;
  let flow = puzzle.trace(turns);
  const history = [];
  const cells = [];
  const activeAnimations = new Map();
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const paths = {
    elbow: 'M50 -3V27Q50 50 73 50H103',
    straight: 'M50 -3V103',
    tee: 'M50 -3V50M-3 50H103',
    end: 'M50 -3V50'
  };
  const shapeNames = { elbow: 'corner', straight: 'straight channel', tee: 'three-way branch', end: 'dead end' };
  const coordinate = (index) => `${String.fromCharCode(65 + Math.floor(index / 6))}${index % 6 + 1}`;

  puzzle.tiles.forEach((tile, index) => {
    const cell = document.createElement('button');
    cell.className = 'ceramic-tile';
    cell.type = 'button';
    cell.dataset.index = index;
    cell.tabIndex = index === selected ? 0 : -1;
    const path = paths[tile.shape];
    cell.innerHTML = `<span class="ceramic-tile__piece" style="--angle:${turns[index] * 90}deg">
      <svg class="ceramic-tile__art" viewBox="0 0 100 100" aria-hidden="true">
        <rect class="ceramic-tile__speckles" width="100" height="100"/>
        <path class="ceramic-tile__groove-edge" d="${path}"/>
        <path class="ceramic-tile__groove" d="${path}" transform="translate(0 1)"/>
        ${tile.shape === 'end' ? '<circle class="ceramic-tile__end" cx="50" cy="50" r="15"/>' : ''}
        <path class="ceramic-tile__groove-light" d="${path}" transform="translate(10 0)"/>
        <g class="ceramic-tile__water">
          <path class="ceramic-tile__flow" d="${path}"/>
          ${tile.shape === 'end' ? '<circle class="ceramic-tile__end-water" cx="50" cy="50" r="12"/>' : ''}
          <path class="ceramic-tile__flow-light" d="${path}" transform="translate(-4 0)"/>
        </g>
      </svg></span><span class="ceramic-tile__coordinate" aria-hidden="true">${coordinate(index)}</span>`;
    cell.addEventListener('focus', () => select(index));
    cell.addEventListener('click', (event) => { select(index); rotate(index, event.shiftKey ? -1 : 1); });
    board.append(cell);
    cells.push({ button: cell, piece: cell.querySelector('.ceramic-tile__piece'), water: cell.querySelector('.ceramic-tile__water') });
  });

  function select(index, focus = false) {
    cells[selected]?.button.setAttribute('tabindex', '-1');
    selected = index;
    cells[selected].button.tabIndex = 0;
    if (focus) cells[selected].button.focus({ preventScroll: true });
  }
  function remember() { history.push({ turns: [...turns], moveCount }); }
  function announce(message) { $('action-announcement').textContent = message; }
  function rotate(index, direction) {
    if (flow.solved) return;
    remember();
    turns[index] += direction;
    moveCount++;
    const cell = cells[index];
    angles[index] += direction * 90;
    cell.piece.style.setProperty('--angle', `${angles[index]}deg`);
    cell.button.classList.add('is-moving');
    activeAnimations.get(index)?.cancel();
    if (!reducedMotion.matches) {
      const animation = cell.button.animate([
        { transform: 'translateY(0)' },
        { transform: 'translateY(-4px)', offset: .24 },
        { transform: 'translateY(0)' }
      ], { duration: 280, easing: 'cubic-bezier(.18,.72,.24,1)' });
      activeAnimations.set(index, animation);
      animation.onfinish = () => { cell.button.classList.remove('is-moving'); activeAnimations.delete(index); };
    } else cell.button.classList.remove('is-moving');
    render();
  }
  function restore(snapshot) {
    activeAnimations.forEach((animation) => animation.cancel());
    activeAnimations.clear();
    turns = [...snapshot.turns];
    moveCount = snapshot.moveCount;
    cells.forEach((cell, index) => {
      cell.button.classList.remove('is-moving');
      // Restore via the nearest equivalent angle, avoiding several full spins.
      const delta = ((turns[index] * 90 - angles[index]) % 360 + 540) % 360 - 180;
      angles[index] += delta;
      cell.piece.style.setProperty('--angle', `${angles[index]}deg`);
    });
    render();
  }
  function undo() {
    if (!history.length) return;
    restore(history.pop());
    announce(`Undone. ${moveCount} ${moveCount === 1 ? 'turn' : 'turns'}. ${flow.solved ? 'The basin is full.' : `${flow.wet.size} tiles flowing.`}`);
  }
  function reset() {
    if (isInitial()) return;
    remember();
    restore({ turns: initial, moveCount: 0 });
    announce('Board reset. Undo brings back your previous path.');
  }
  function isInitial() { return moveCount === 0 && turns.every((turn, index) => turn === initial[index]); }

  function render() {
    flow = puzzle.trace(turns);
    cells.forEach((cell, index) => {
      const wet = flow.wet.has(index);
      cell.water.classList.toggle('is-wet', wet);
      const openings = puzzle.directions.filter((d) => flow.masks[index] & d.bit).map((d) => d.name).join(', ');
      cell.button.setAttribute('aria-label', `${coordinate(index)}, ${shapeNames[puzzle.tiles[index].shape]}, openings ${openings}, ${wet ? 'water flowing' : 'dry'}. ${flow.solved ? 'Puzzle complete.' : 'Turn clockwise.'}`);
      cell.button.setAttribute('aria-disabled', String(flow.solved));
      cell.button.dataset.turn = String(((turns[index] % 4) + 4) % 4);
      cell.button.dataset.wet = String(wet);
    });
    board.dataset.solved = String(flow.solved);
    $('undo-button').disabled = history.length === 0;
    $('reset-button').disabled = isInitial();
    $('reset-button').classList.toggle('ui-button--primary', flow.solved);
    $('reset-label').textContent = flow.solved ? 'Play again' : 'Reset';
    $('turn-count').textContent = String(moveCount).padStart(2, '0');
    $('flow-status').classList.toggle('is-complete', flow.solved);
    $('status-icon').setAttribute('href', flow.solved ? '#icon-check' : '#icon-drop');
    $('status-title').textContent = flow.solved ? 'A path, at last.' : flow.wet.size ? 'The spring is flowing' : 'The water is waiting';
    $('status-description').textContent = flow.solved ? 'The basin is full. Stay a while, or begin again.' : flow.wet.size ? 'Follow the blue. Find a way to the basin.' : 'Turn the tile beside the spring to let it in.';
    $('flow-count').innerHTML = flow.solved ? 'Spring<br>→ basin' : `${flow.wet.size} ${flow.wet.size === 1 ? 'tile' : 'tiles'}<br>flowing`;
    $('basin-label').textContent = flow.solved ? 'Full' : 'Basin';
    ['basin-fill', 'basin-stream', 'basin-ripple'].forEach((id) => $(id).classList.toggle('is-full', flow.solved));
    drawJoins();
  }

  function drawJoins() {
    const bounds = board.getBoundingClientRect();
    if (!bounds.width) return;
    const joins = $('board-joins');
    joins.setAttribute('viewBox', `0 0 ${bounds.width} ${bounds.height}`);
    const boxes = cells.map((cell) => ({ left: cell.button.offsetLeft, top: cell.button.offsetTop, width: cell.button.offsetWidth, height: cell.button.offsetHeight }));
    const lines = [];
    boxes.forEach((box, index) => {
      for (const direction of [puzzle.directions[1], puzzle.directions[2]]) {
        const next = puzzle.neighbor(index, direction);
        if (next < 0 || !(flow.masks[index] & direction.bit) || !(flow.masks[next] & direction.opposite)) continue;
        const target = boxes[next];
        const horizontal = direction.dc === 1;
        const x1 = horizontal ? box.left + box.width : box.left + box.width / 2;
        const y1 = horizontal ? box.top + box.height / 2 : box.top + box.height;
        const x2 = horizontal ? target.left : target.left + target.width / 2;
        const y2 = horizontal ? target.top + target.height / 2 : target.top;
        const wet = flow.wet.has(index);
        lines.push(`<line class="ceramic-board__joint" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke-width="${box.width * .25}"/>`);
        if (wet) lines.push(`<line class="ceramic-board__joint ceramic-board__joint--wet" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke-width="${box.width * .18}"/>`);
      }
    });
    joins.innerHTML = lines.join('');
  }

  board.addEventListener('keydown', (event) => {
    const arrows = { ArrowUp: -6, ArrowDown: 6, ArrowLeft: -1, ArrowRight: 1 };
    if (Object.hasOwn(arrows, event.key)) {
      event.preventDefault();
      const row = Math.floor(selected / 6), column = selected % 6;
      if ((event.key === 'ArrowLeft' && column === 0) || (event.key === 'ArrowRight' && column === 5) || (event.key === 'ArrowUp' && row === 0) || (event.key === 'ArrowDown' && row === 4)) return;
      select(selected + arrows[event.key], true);
    } else if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      if (!event.repeat) rotate(selected, event.shiftKey ? -1 : 1);
    } else if (event.key === 'Home' || event.key === 'End') {
      event.preventDefault();
      select(event.key === 'Home' ? Math.floor(selected / 6) * 6 : Math.floor(selected / 6) * 6 + 5, true);
    }
  });
  document.addEventListener('keydown', (event) => {
    if (event.altKey || event.repeat) return;
    const key = event.key.toLowerCase();
    const commandUndo = (event.ctrlKey || event.metaKey) && key === 'z' && !event.shiftKey;
    const local = board.contains(document.activeElement) || document.activeElement === $('undo-button') || document.activeElement === $('reset-button');
    if (commandUndo || (local && key === 'u' && !event.ctrlKey && !event.metaKey)) { event.preventDefault(); undo(); }
    else if (local && key === 'r' && !event.ctrlKey && !event.metaKey) { event.preventDefault(); reset(); }
  });
  $('undo-button').addEventListener('click', undo);
  $('reset-button').addEventListener('click', reset);
  new ResizeObserver(drawJoins).observe(board);
  render();
})();
